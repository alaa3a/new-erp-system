## Task 3: GET /api/invoices/[id]/entries + GET /api/dashboard/summary

### Files:
- Create: `src/app/api/invoices/[id]/entries/route.ts` (GET)
- Create: `src/app/api/dashboard/summary/route.ts` (GET)

### Steps:

- [ ] **Step 1: Create `invoices/[id]/entries/route.ts`**

Create directory `src/app/api/invoices/[id]/entries/` and file `route.ts`.

The GET handler should:
1. Call `requireAuth(_request)` and return early if auth is a NextResponse
2. Call `ensureInitialized()`
3. Parse `invoiceId` from `params`
4. Look up invoice via `invoiceRepository.findById(invoiceId)` — throw `NotFoundError('Invoice', invoiceId)` if not found
5. Find linked entries via `entryRepository.findByLinkedInvoice(invoiceId)` — this returns entries with `linkedInvoiceId = invoiceId`
6. For each entry found, attach its lines via `entryRepository.findLines(entry.id)`
7. Return `Response.json({ success: true, data: entries })`

- [ ] **Step 2: Create `dashboard/summary/route.ts`**

Create directory `src/app/api/dashboard/summary/` and file `route.ts`.

The GET handler should provide a summary of key business metrics:
1. Call `requireAuth(request)` and return early if auth is a NextResponse
2. Call `ensureInitialized()`
3. Calculate:
   - `totalSales`: Sum of `totalAmount` for non-draft sales invoices
   - `totalPurchases`: Sum of `totalAmount` for non-draft purchase invoices
   - `totalOverdue`: Sum of balances from `agingService.getOverdueReceivables()`
   - `invoiceCount`: Total count of all invoices
   - `partnerCount`: Count of active partners
   - `productCount`: Count of active products
   - `overdueInvoices`: Count of overdue invoices
4. Return `Response.json({ success: true, data: { totalSales, totalPurchases, totalOverdue, invoiceCount, partnerCount, productCount, overdueInvoices } })`

Use `invoiceRepository.findAll()`, `partnerRepository.findAll()`, `productRepository.findAll()`, and `agingService.getOverdueReceivables()`.

- [ ] **Step 3: Verify build**

```bash
cd "D:\open code\project\NEW ERP"
npx next build 2>&1 | Select-String "Compiled successfully"
```
