## Task 5: PUT /api/users/[id]/permissions + POST /api/auth/reset-password

### Files:
- Create: `src/app/api/users/[id]/permissions/route.ts` (PUT)
- Create: `src/app/api/auth/reset-password/route.ts` (POST)

### Steps:

- [ ] **Step 1: Create `users/[id]/permissions/route.ts`**

Create directory `src/app/api/users/[id]/permissions/` and file `route.ts`.

The PUT handler should:
1. Call `requireAuth(request)` and return early if auth is a NextResponse
2. Call `ensureInitialized()`
3. Parse `userId` from `params`
4. Look up user via `userRepository.findById(userId)` — throw `NotFoundError('User', userId)` if not found
5. Parse body and validate `Array.isArray(body.permissionIds)` — throw `ValidationError('permissionIds must be an array')` if not
6. Call `userRepository.updatePermissions(userId, body.permissionIds)` — this method already exists
7. Re-fetch the updated user via `userRepository.findById(userId)`
8. Return `Response.json({ success: true, data: updated })`

- [ ] **Step 2: Create `auth/reset-password/route.ts`**

Create directory `src/app/api/auth/reset-password/` and file `route.ts`.

The POST handler should:
1. Call `requireAuth(request)` and return early if auth is a NextResponse
2. Call `ensureInitialized()`
3. Parse body for `email` and `newPassword`
4. Validate presence: throw `ValidationError('Email and new password are required')` if either missing
5. Validate password length: throw `ValidationError('Password must be at least 6 characters')` if `< 6`
6. Look up user via `userRepository.findByEmail(body.email)` — throw `NotFoundError('User with email ' + body.email)` if not found
7. Hash password via `hashPassword(body.newPassword)` from `@/lib/auth/password` — note: **synchronous**, returns string directly (no await)
8. Update user via raw SQL `db.prepare('UPDATE users SET passwordHash=? WHERE id=?').run(hashed, user.id)` — the userRepository.update requires a version parameter, so use db directly
9. Return `Response.json({ success: true, data: { message: 'Password reset successfully' } })`

- [ ] **Step 3: Verify build**

```bash
cd "D:\open code\project\NEW ERP"
npx next build 2>&1 | Select-String "Compiled successfully"
```
