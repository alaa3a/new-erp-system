## Task 2: Update 5 route GET handlers to use paginate()

### Files:
- Modify: `src/app/api/entries/route.ts`
- Modify: `src/app/api/invoices/route.ts`
- Modify: `src/app/api/partners/route.ts`
- Modify: `src/app/api/products/route.ts`
- Modify: `src/app/api/purchase-orders/route.ts`

### Steps:

- [ ] **Step 1: Update entries GET handler**

In `src/app/api/entries/route.ts`, replace the GET handler body lines that do:
```ts
const entries = entryRepository.findAll(type, status, search);
return NextResponse.json({ success: true, data: entries });
```
With:
```ts
const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
const pageSize = Math.min(100, Math.max(1, parseInt(searchParams.get('pageSize') || '20', 10)));
const result = entryRepository.paginate(page, pageSize, type, status, search);
return NextResponse.json({ success: true, data: result.data, total: result.total, page, pageSize });
```

- [ ] **Step 2: Update invoices GET handler**

Replace the `invoiceRepository.findAll(...)` call and return with:
```ts
const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
const pageSize = Math.min(100, Math.max(1, parseInt(searchParams.get('pageSize') || '20', 10)));
const result = invoiceRepository.paginate(page, pageSize, type, status, search);
return NextResponse.json({ success: true, data: result.data, total: result.total, page, pageSize });
```

- [ ] **Step 3: Update partners GET handler**

Replace the `partnerRepository.findAll(search, type)` call and return with:
```ts
const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
const pageSize = Math.min(100, Math.max(1, parseInt(searchParams.get('pageSize') || '20', 10)));
const result = partnerRepository.paginate(page, pageSize, search, type);
return NextResponse.json({ success: true, data: result.data, total: result.total, page, pageSize });
```

- [ ] **Step 4: Update products GET handler**

Replace the `productRepository.findAll(search, itemType)` call and return with:
```ts
const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
const pageSize = Math.min(100, Math.max(1, parseInt(searchParams.get('pageSize') || '20', 10)));
const result = productRepository.paginate(page, pageSize, search, itemType);
return NextResponse.json({ success: true, data: result.data, total: result.total, page, pageSize });
```

- [ ] **Step 5: Update purchase-orders GET handler**

The current handler is:
```ts
const pos = purchaseOrderRepository.findAll(status, search);
const result = pos.map(po => ({ ...po, lines: purchaseOrderRepository.findLines(po.id) }));
return NextResponse.json({ success: true, data: result });
```
Replace with:
```ts
const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
const pageSize = Math.min(100, Math.max(1, parseInt(searchParams.get('pageSize') || '20', 10)));
const result = purchaseOrderRepository.paginate(page, pageSize, status, search);
const data = result.data.map(po => ({ ...po, lines: purchaseOrderRepository.findLines(po.id) }));
return NextResponse.json({ success: true, data, total: result.total, page, pageSize });
```

- [ ] **Step 6: Verify build**

```bash
cd "D:\open code\project\NEW ERP"
npx next build 2>&1 | Select-String "Compiled successfully"
```
