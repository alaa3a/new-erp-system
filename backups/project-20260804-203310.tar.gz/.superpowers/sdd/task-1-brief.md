## Task 1: DELETE /api/entries/[id] + entries ledger route

### Files:
- Modify: `src/app/api/entries/[id]/route.ts` (add DELETE handler)
- Create: `src/app/api/entries/ledger/route.ts` (GET)

### Steps:

- [ ] **Step 1: Add DELETE handler to `entries/[id]/route.ts`**

Read the existing file, then add after the PUT handler. The DELETE handler must:
1. Call `requireAuth(_request)` and return early if auth is a NextResponse
2. Call `ensureInitialized()`
3. Parse `entryId` from `params`
4. Find the entry via `entryRepository.findById(entryId)` — throw `NotFoundError('Entry', entryId)` if not found
5. Check `entry.isPosted || entry.status === 'posted'` — throw `ConflictError('Cannot delete a posted entry. Reverse it instead.')`
6. Delete lines via `entryRepository.deleteLines(entryId)`
7. Add a `delete` method to `entryRepository` if it doesn't exist, then call it
8. Audit log: `auditLogRepository.log({ userId: auth.userId, action: 'delete', entityType: 'entry', entityId: entryId })`
9. Return `Response.json({ success: true, data: { id: entryId } })`

- [ ] **Step 2: Add `delete` method to `entryRepository`**

The `entryRepository` in `src/lib/repositories/entryRepository.ts` currently lacks a `delete` method. Add one:
```ts
delete(id: number): void {
  db.prepare('DELETE FROM entry WHERE id = ?').run(id);
},
```

- [ ] **Step 3: Create `entries/ledger/route.ts`**

Create directory `src/app/api/entries/ledger/` and file `route.ts`:

The GET handler should:
1. Call `requireAuth(request)` and return early if auth is a NextResponse
2. Call `ensureInitialized()`
3. Read query params: `accountCode`, `startDate`, `endDate`
4. Fetch all entries via `entryRepository.findAll()`
5. Filter in-memory by the params
6. For each entry, fetch lines via `entryRepository.findLines(e.id)`
7. Return `Response.json({ success: true, data: result })`

- [ ] **Step 4: Verify build**

```bash
cd "D:\open code\project\NEW ERP"
npx next build 2>&1 | Select-String "Compiled successfully"
```
