# Task 1 Report: Add paginate() to all 5 repositories

## What was implemented

Added a `paginate(page, pageSize, ...filters)` method to 5 repository files, placed after the existing `findAll` method in each. Each method:

- Computes `offset = (page - 1) * pageSize`
- Builds a dynamic `WHERE` clause with the same filters as `findAll`
- Runs a `SELECT count(1) ...` for total count
- Runs `SELECT * ... ORDER BY ... LIMIT ? OFFSET ?` for data
- Maps results through the repo's existing mapper function
- Returns `{ data: T[], total: number }`

### Files changed

| File | Mapper | Filters |
|------|--------|---------|
| `src/lib/repositories/entryRepository.ts` | `mapEntry` | type, status, search |
| `src/lib/repositories/invoiceRepository.ts` | `mapInvoice` | type, status, search |
| `src/lib/repositories/partnerRepository.ts` | `mapRow` | search, type |
| `src/lib/repositories/productRepository.ts` | `mapRow` | search, itemType |
| `src/lib/repositories/purchaseOrderRepository.ts` | `mapPO` | status, search |

## Testing

- Ran `npx next build` — **Compiled successfully** (no type errors, no build failures)

## Self-review

- All paginate methods correctly mirror their corresponding `findAll` filters and ordering
- No `await` used — consistent with the synchronous sql.js pattern in the codebase
- Return types are properly annotated with the entity type
- The LIMIT/OFFET parameters are appended after the filter params in the `.all()` call, which is correct for sql.js parameter binding

## Issues or concerns

- `partnerRepository.ts` and `productRepository.ts` both use `mapRow` as their mapper name — this is correct per the existing code in each file
- The 4 non-entry repository files were not previously tracked in git (they show as "create mode" in the commit), but they contain the complete existing code plus the new paginate method

## Commit

`ba4d826` — feat: add paginate() to all 5 list repositories
