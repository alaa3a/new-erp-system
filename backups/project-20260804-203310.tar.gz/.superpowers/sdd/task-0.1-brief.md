## Task 0.1: Split co-located repositories into dedicated files

**Context:** The files `src/lib/repositories/taxCodeRepository.ts` and `src/lib/repositories/fiscalPeriodRepository.ts` each export multiple repository objects. They should be split into dedicated files for clean imports and maintainability.

**What to do:**
1. Create `src/lib/repositories/postingProfileRepository.ts` — export `postingProfileRepository` object with `findAll`, `findById`, `create`, `update`, `softDelete` methods (same code currently in `taxCodeRepository.ts`)
2. Create `src/lib/repositories/paymentTermRepository.ts` — export `paymentTermRepository` object
3. Create `src/lib/repositories/entryCategoryRepository.ts` — export `entryCategoryRepository` object
4. Create `src/lib/repositories/companyRepository.ts` — export `companyRepository` object with `get`, `create`, `update` methods (currently in `fiscalPeriodRepository.ts`)
5. Create `src/lib/repositories/sequenceRepository.ts` — export `sequenceRepository` object with `findAll`, `getNext`, `update` methods
6. Update imports in 8 route files to import from the new dedicated files instead of from `taxCodeRepository` or `fiscalPeriodRepository`

**8 route files to fix imports:**

| Route File | Change Import FROM | Change Import TO |
|-----------|-------------------|-----------------|
| `src/app/api/posting-profiles/route.ts` | `@/lib/repositories/taxCodeRepository` | `@/lib/repositories/postingProfileRepository` |
| `src/app/api/posting-profiles/[id]/route.ts` | `@/lib/repositories/taxCodeRepository` | `@/lib/repositories/postingProfileRepository` |
| `src/app/api/payment-terms/route.ts` | `@/lib/repositories/taxCodeRepository` | `@/lib/repositories/paymentTermRepository` |
| `src/app/api/payment-terms/[id]/route.ts` | `@/lib/repositories/taxCodeRepository` | `@/lib/repositories/paymentTermRepository` |
| `src/app/api/entry-categories/route.ts` | `@/lib/repositories/taxCodeRepository` | `@/lib/repositories/entryCategoryRepository` |
| `src/app/api/entry-categories/[id]/route.ts` | `@/lib/repositories/taxCodeRepository` | `@/lib/repositories/entryCategoryRepository` |
| `src/app/api/company/route.ts` | `@/lib/repositories/fiscalPeriodRepository` | `@/lib/repositories/companyRepository` |
| `src/app/api/document-sequences/route.ts` | `@/lib/repositories/fiscalPeriodRepository` | `@/lib/repositories/sequenceRepository` |

**Note:** The import names stay the same (e.g., `postingProfileRepository`). Only the file path changes. The existing code in `taxCodeRepository.ts` and `fiscalPeriodRepository.ts` should NOT be modified — the duplicated exports can remain there for now.

**Verification:** Run `npm run build` — must pass with no errors.
