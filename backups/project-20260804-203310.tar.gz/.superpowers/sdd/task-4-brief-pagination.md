## Task 4: Update 6 page files to use paginated fetch

### Files to modify:
- `src/app/(admin)/accounting/entries/page.tsx`
- `src/app/(admin)/invoice/sales/page.tsx`
- `src/app/(admin)/invoice/purchase/page.tsx`
- `src/app/(admin)/business-partners/page.tsx`
- `src/app/(admin)/products/page.tsx`
- `src/app/(admin)/purchase-orders/page.tsx`

### Pattern:

For each page, you need to:

1. **Read page/pageSize from URL search params** at the top of the component:
```tsx
const searchParams = useSearchParams();
const page = parseInt(searchParams.get('page') || '1', 10);
const pageSize = parseInt(searchParams.get('pageSize') || '20', 10);
```

2. **Add `page` and `pageSize` to the fetch URL** as query params.

3. **Add `page` and `pageSize` to the dependency array** of any `useEffect` that triggers the fetch.

4. **Render `<Pagination>` below the table**:
```tsx
<Pagination page={json.page} pageSize={json.pageSize} total={json.total} />
```

5. **Ensure `'use client'` is present** at the top of the file.

6. **Import Pagination**:
```tsx
import { Pagination } from '@/components/Pagination';
```

### API routes mapped to each page:

| Page | API URL | Fetch params |
|------|---------|-------------|
| accounting/entries | `/api/entries` | `type`, `status`, `search` |
| invoice/sales | `/api/invoices?type=sales` | `status`, `search` |
| invoice/purchase | `/api/invoices?type=purchase` | `status`, `search` |
| business-partners | `/api/partners` | `search`, `type` |
| products | `/api/products` | `search`, `itemType` |
| purchase-orders | `/api/purchase-orders` | `status`, `search` |

### Steps:

- [ ] Step 1: Update `entries/page.tsx`
- [ ] Step 2: Update `invoice/sales/page.tsx`
- [ ] Step 3: Update `invoice/purchase/page.tsx`
- [ ] Step 4: Update `business-partners/page.tsx`
- [ ] Step 5: Update `products/page.tsx`
- [ ] Step 6: Update `purchase-orders/page.tsx`
- [ ] Step 7: Verify build

```bash
cd "D:\open code\project\NEW ERP"
npx next build 2>&1 | Select-String "Compiled successfully"
Expected: ✓ Compiled successfully in ...
```
