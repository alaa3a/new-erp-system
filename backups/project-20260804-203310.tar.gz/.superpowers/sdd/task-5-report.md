# Task 5 Report: PUT /api/users/[id]/permissions + POST /api/auth/reset-password

## What I Implemented

1. **`src/app/api/users/[id]/permissions/route.ts`** — PUT handler that:
   - Requires authentication via `requireAuth`
   - Looks up user by ID, throws `NotFoundError` if missing
   - Validates `body.permissionIds` is an array, throws `ValidationError` if not
   - Calls `userRepository.updatePermissions(userId, body.permissionIds)`
   - Re-fetches and returns the updated user

2. **`src/app/api/auth/reset-password/route.ts`** — POST handler that:
   - Requires authentication via `requireAuth`
   - Validates `email` and `newPassword` are present (throws `ValidationError`)
   - Validates password length >= 6 (throws `ValidationError`)
   - Looks up user via `userRepository.findByEmail(email)` (throws `NotFoundError`)
   - Hashes password with `hashPassword()` (synchronous, no await)
   - Updates via `db.prepare('UPDATE users SET passwordHash=? WHERE id=?').run(hashed, user.id)` directly (no version parameter needed)

## What I Tested

- `npx next build` completed successfully with "Compiled successfully"
- Both routes appear in the build output:
  - `ƒ /api/users/[id]/permissions` (dynamic, server-rendered)
  - `ƒ /api/auth/reset-password` (dynamic, server-rendered)

## Files Changed

| File | Action |
|------|--------|
| `src/app/api/users/[id]/permissions/route.ts` | Created |
| `src/app/api/auth/reset-password/route.ts` | Created |

## Self-Review Findings

- Both routes follow existing code patterns from `users/[id]/route.ts` (try/catch + handleApiError, requireAuth check)
- Imports match the task brief's specified available imports exactly
- No `await` on `hashPassword()` — confirmed synchronous from usage in `users/route.ts:40` and `users/[id]/route.ts:83`
- `userRepository.updatePermissions(userId, permissionIds)` used directly — confirmed exists at `userRepository.ts:10`
- Reset password uses raw `db.prepare()` to avoid the version requirement of `userRepository.update()`

## Issues or Concerns

- **No audit logging** — unlike the existing `users/[id]/route.ts` PUT handler, neither new route logs audit entries. This is consistent with the task brief which didn't mention audit logging for these routes.
- **Reset password bypasses optimistic locking** — uses direct SQL `WHERE id=?` without version check. This is intentional per the brief since `userRepository.update()` requires version but the reset-password use case doesn't need it.
