# Task 1 Report: DELETE /api/entries/[id] + entries/ledger route

## What was implemented

1. **`src/lib/repositories/entryRepository.ts`** — Added `delete(id: number): void` method that runs `DELETE FROM entry WHERE id = ?`.

2. **`src/app/api/entries/[id]/route.ts`** — Added `DELETE` handler that:
   - Authenticates via `requireAuth`
   - Looks up entry by ID, throws `NotFoundError` if missing
   - Rejects posted entries with `ConflictError('Cannot delete a posted entry. Reverse it instead.')`
   - Deletes lines via `deleteLines`, then entry via `delete`
   - Logs audit via `auditLogRepository.log`
   - Returns `{ success: true, data: { id } }`

3. **`src/app/api/entries/ledger/route.ts`** — Created `GET` handler that:
   - Authenticates and initializes
   - Reads `accountCode`, `startDate`, `endDate` query params
   - Fetches all entries via `findAll()`, filters in-memory by date range
   - Attaches lines via `findLines(e.id)` for each entry
   - If `accountCode` provided, filters entries to only those with matching line account codes

## What was tested

- `npx next build` — **Compiled successfully** (no errors, no warnings)

## Files changed

| File | Change |
|------|--------|
| `src/lib/repositories/entryRepository.ts` | Added `delete()` method |
| `src/app/api/entries/[id]/route.ts` | Added `DELETE` handler |
| `src/app/api/entries/ledger/route.ts` | Created new file (GET handler) |

## Self-review findings

- The `DELETE` handler uses `entry.status === 'posted'` as per the field name in the `Entry` type (not `isPosted`).
- The plan mentioned `entry.isPosted || entry.status === 'posted'` but since there's no `isPosted` field, only the `status` check is used.
- `FindByReference` was mentioned in the plan but `findByLinkedInvoice` exists — the ledger route uses `findAll()` + filter, not `findByLinkedInvoice`, which is appropriate.
- All method names match the actual signatures (`findLines`, `deleteLines`, `delete`, `findById`, `findAll`, etc.).

## Issues or concerns

None.
