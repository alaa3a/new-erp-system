## Task 2: GET /api/partners/[id]/aging + GET /api/products/[id]/stock

### Files:
- Create: `src/app/api/partners/[id]/aging/route.ts` (GET)
- Create: `src/app/api/products/[id]/stock/route.ts` (GET)

### Steps:

- [ ] **Step 1: Create `partners/[id]/aging/route.ts`**

Create directory `src/app/api/partners/[id]/aging/` and file `route.ts`.

The GET handler should:
1. Call `requireAuth(_request)` and return early if auth is a NextResponse
2. Call `ensureInitialized()`
3. Parse `partnerId` from `params`
4. Look up partner via `partnerRepository.findById(partnerId)` — throw `NotFoundError('Partner', partnerId)` if not found
5. Call `agingService.calculatePartnerAging(partnerId)` — this returns the aging buckets for that partner
6. Return `Response.json({ success: true, data: aging })`

- [ ] **Step 2: Create `products/[id]/stock/route.ts`**

Create directory `src/app/api/products/[id]/stock/` and file `route.ts`.

The GET handler should:
1. Call `requireAuth(_request)` and return early if auth is a NextResponse
2. Call `ensureInitialized()`
3. Parse `productId` from `params`
4. Look up product via `productRepository.findById(productId)` — throw `NotFoundError('Product', productId)` if not found
5. Call `inventoryRepository.getAllStock(productId)` — returns stock data across all warehouses
6. Return `Response.json({ success: true, data: stock })`

- [ ] **Step 3: Verify build**

```bash
cd "D:\open code\project\NEW ERP"
npx next build 2>&1 | Select-String "Compiled successfully"
```
