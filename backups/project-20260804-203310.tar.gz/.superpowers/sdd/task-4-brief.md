## Task 4: Reports routes — inventory-valuation, tax-summary

### Files:
- Create: `src/app/api/reports/inventory-valuation/route.ts` (GET)
- Create: `src/app/api/reports/tax-summary/route.ts` (GET)

### Note:
- `GET /api/reports/inventory-movements` is NOT needed — `GET /api/inventory/movements` already exists at `src/app/api/inventory/movements/route.ts`

### Steps:

- [ ] **Step 1: Create `reports/inventory-valuation/route.ts`**

Create directory `src/app/api/reports/inventory-valuation/` and file `route.ts`.

The GET handler should:
1. Call `requireAuth(request)` and return early if auth is a NextResponse
2. Call `ensureInitialized()`
3. Call `inventoryRepository.getValuation()` — this already exists and returns per-warehouse valuation with product name, warehouse name, quantity, average cost, total value
4. Return `Response.json({ success: true, data: valuation })`

Note: Do NOT iterate products and call getStock manually — `getValuation()` already does the right join.

- [ ] **Step 2: Create `reports/tax-summary/route.ts`**

Create directory `src/app/api/reports/tax-summary/` and file `route.ts`.

The GET handler should:
1. Call `requireAuth(request)` and return early if auth is a NextResponse
2. Call `ensureInitialized()`
3. Read optional query params: `startDate`, `endDate`
4. Fetch invoices via `invoiceRepository.findAll()` — filter by date range in-memory
5. For each invoice, fetch its lines via `invoiceRepository.findLines(invoice.id)`
6. Group lines by `vatCodeId`, mapping to tax code names via `taxCodeRepository.findAll()`
7. Compute for each vat code: sum of `lineTotal` (taxable amount), sum of `vatAmount`, invoice count
8. Return `Response.json({ success: true, data: summary })`

The response should be an array of:
```ts
{
  vatCode: string;       // from taxCode.code
  vatName: string;       // from taxCode.name
  rate: number;           // from taxCode.rate
  taxableAmount: number;  // sum of lineTotal
  taxAmount: number;      // sum of vatAmount
  invoiceCount: number;   // unique invoice count
}
```

- [ ] **Step 3: Verify build**

```bash
cd "D:\open code\project\NEW ERP"
npx next build 2>&1 | Select-String "Compiled successfully"
```
