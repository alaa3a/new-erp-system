# Task 4: Pagination Integration - List Pages

## Objective
Integrate the `Pagination` component into 6 admin list page files, enabling server-side paginated data fetching.

## Pages Updated

| Page | Layout | Filters | Status |
|------|--------|---------|--------|
| `accounting/entries` | Table | type, status, search | Done |
| `invoice/sales` | Table | status, search (+ type=sales) | Done |
| `invoice/purchase` | Table | status, search (+ type=purchase) | Done |
| `business-partners` | Cards | search, type | Done |
| `products` | Cards | search, itemType | Done |
| `purchase-orders` | Table | status, search | Done |

## Changes Made (per page)
1. Added `useSearchParams` from `next/navigation`
2. Added `Pagination` component import
3. Added `total` state variable
4. Read `page` and `pageSize` from URL search params
5. Updated fetch URLs to include `?page=X&pageSize=Y` plus existing filter params
6. Stored `json.total` from API response into state
7. Added `page`, `pageSize` to `useCallback` dependency arrays
8. Rendered `<Pagination page={page} pageSize={pageSize} total={total} />` below list
9. Added `export const dynamic = 'force-dynamic'` to skip prerendering
10. Wrapped `useSearchParams`-dependent component in `<Suspense>` boundary per Next.js 16 requirement

## Build Result
- `✓ Compiled successfully`
- All 6 pages deployed as dynamic routes

## Files Committed
- `src/app/(admin)/accounting/entries/page.tsx`
- `src/app/(admin)/invoice/sales/page.tsx`
- `src/app/(admin)/invoice/purchase/page.tsx`
- `src/app/(admin)/business-partners/page.tsx`
- `src/app/(admin)/products/page.tsx`
- `src/app/(admin)/purchase-orders/page.tsx`
