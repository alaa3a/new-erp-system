## Combined Phase Batch 1: Simple CRUD Routes

Update these route files to use the standard API format `{ success: true, data }` and add auth middleware to POST/PUT/DELETE.

**Files to update (12 files):**
- `src/app/api/accounts/route.ts`
- `src/app/api/accounts/[id]/route.ts`
- `src/app/api/partners/route.ts`
- `src/app/api/partners/[id]/route.ts`
- `src/app/api/products/route.ts`
- `src/app/api/products/[id]/route.ts`
- `src/app/api/warehouses/route.ts`
- `src/app/api/warehouses/[id]/route.ts`
- `src/app/api/cost-centers/route.ts`
- `src/app/api/cost-centers/[id]/route.ts`
- `src/app/api/company/route.ts`
- `src/app/api/document-sequences/route.ts`

**Changes to make in each file:**

### 1. Add auth import
```typescript
import { requireAuth } from '@/lib/auth/middleware'
```

### 2. Add auth to POST/PUT/DELETE handlers
At the start of each POST/PUT/DELETE function body:
```typescript
const auth = await requireAuth(request)
if (auth instanceof NextResponse) return auth
```
Then replace hardcoded `userId: 1` with `auth.userId`.

### 3. Wrap success responses
```typescript
// BEFORE:
return NextResponse.json(data)
return NextResponse.json({ id })
return NextResponse.json({ success: true })

// AFTER:
return NextResponse.json({ success: true, data })
return NextResponse.json({ success: true, data: { id } })
// (keep { success: true } as-is)
```

### 4. Wrap error responses
```typescript
// BEFORE:
return NextResponse.json({ error: '...' }, { status: 400 })
// AFTER:
return NextResponse.json({ success: false, error: '...' }, { status: 400 })
```

### 5. Update handleApiError if needed
Check that error responses from `handleApiError` also return `{ success: false, error }`.

**Files to specifically check for error format:**
- `src/app/api/accounts/[id]/route.ts` — line 78-80 returns `{ error }` format
- `src/app/api/cost-centers/[id]/route.ts` — was just rewritten, check current format

**IMPORTANT:** Do NOT change the `NextResponse` import — it's already imported.

**Verification:** Run `npm run build` and confirm it passes.
