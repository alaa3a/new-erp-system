## Task 1: Add paginate() to all 5 repositories

### Files:
- Modify: `src/lib/repositories/entryRepository.ts`
- Modify: `src/lib/repositories/invoiceRepository.ts`
- Modify: `src/lib/repositories/partnerRepository.ts`
- Modify: `src/lib/repositories/productRepository.ts`
- Modify: `src/lib/repositories/purchaseOrderRepository.ts`

### Steps:

- [ ] **Step 1: Add `paginate()` to entryRepository**

Read the file, then add after the `findAll` method:

```ts
  paginate(page: number, pageSize: number, type?: string, status?: string, search?: string): { data: Entry[]; total: number } {
    const offset = (page - 1) * pageSize;
    let where = 'WHERE 1=1';
    const params: any[] = [];
    if (type) { where += ' AND type = ?'; params.push(type); }
    if (status) { where += ' AND status = ?'; params.push(status); }
    if (search) { where += ' AND (entryNumber LIKE ? OR description LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
    const total = (db.prepare(`SELECT count(1) AS count FROM entry ${where}`).get(...params) as any).count;
    const data = (db.prepare(`SELECT * FROM entry ${where} ORDER BY createdAt DESC LIMIT ? OFFSET ?`).all(...params, pageSize, offset) as any[]).map(mapEntry);
    return { data, total };
  },
```

- [ ] **Step 2: Add `paginate()` to invoiceRepository**

```ts
  paginate(page: number, pageSize: number, type?: string, status?: string, search?: string): { data: Invoice[]; total: number } {
    const offset = (page - 1) * pageSize;
    let where = 'WHERE 1=1';
    const params: any[] = [];
    if (type) { where += ' AND type = ?'; params.push(type); }
    if (status) { where += ' AND status = ?'; params.push(status); }
    if (search) { where += ' AND (invoiceNumber LIKE ? OR partnerName LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
    const total = (db.prepare(`SELECT count(1) AS count FROM invoice ${where}`).get(...params) as any).count;
    const data = (db.prepare(`SELECT * FROM invoice ${where} ORDER BY createdAt DESC LIMIT ? OFFSET ?`).all(...params, pageSize, offset) as any[]).map(mapInvoice);
    return { data, total };
  },
```

- [ ] **Step 3: Add `paginate()` to partnerRepository**

```ts
  paginate(page: number, pageSize: number, search?: string, type?: string): { data: BusinessPartner[]; total: number } {
    const offset = (page - 1) * pageSize;
    let where = "WHERE status != 'deleted'";
    const params: any[] = [];
    if (search) { where += ' AND (name LIKE ? OR code LIKE ? OR email LIKE ?)'; params.push(`%${search}%`, `%${search}%`, `%${search}%`); }
    if (type) { where += ' AND type = ?'; params.push(type); }
    const total = (db.prepare(`SELECT count(1) AS count FROM business_partner ${where}`).get(...params) as any).count;
    const data = (db.prepare(`SELECT * FROM business_partner ${where} ORDER BY name ASC LIMIT ? OFFSET ?`).all(...params, pageSize, offset) as any[]).map(mapRow);
    return { data, total };
  },
```

- [ ] **Step 4: Add `paginate()` to productRepository**

```ts
  paginate(page: number, pageSize: number, search?: string, itemType?: string): { data: Product[]; total: number } {
    const offset = (page - 1) * pageSize;
    let where = 'WHERE isActive = 1';
    const params: any[] = [];
    if (search) { where += ' AND (name LIKE ? OR code LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
    if (itemType) { where += ' AND itemType = ?'; params.push(itemType); }
    const total = (db.prepare(`SELECT count(1) AS count FROM product ${where}`).get(...params) as any).count;
    const data = (db.prepare(`SELECT * FROM product ${where} ORDER BY name ASC LIMIT ? OFFSET ?`).all(...params, pageSize, offset) as any[]).map(mapRow);
    return { data, total };
  },
```

- [ ] **Step 5: Add `paginate()` to purchaseOrderRepository**

```ts
  paginate(page: number, pageSize: number, status?: string, search?: string): { data: PurchaseOrder[]; total: number } {
    const offset = (page - 1) * pageSize;
    let where = 'WHERE 1=1';
    const params: any[] = [];
    if (status) { where += ' AND status = ?'; params.push(status); }
    if (search) { where += ' AND (poNumber LIKE ? OR partnerName LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
    const total = (db.prepare(`SELECT count(1) AS count FROM purchase_order ${where}`).get(...params) as any).count;
    const data = (db.prepare(`SELECT * FROM purchase_order ${where} ORDER BY createdAt DESC LIMIT ? OFFSET ?`).all(...params, pageSize, offset) as any[]).map(mapPO);
    return { data, total };
  },
```

- [ ] **Step 6: Verify build**

```bash
cd "D:\open code\project\NEW ERP"
npx next build 2>&1 | Select-String "Compiled successfully"
```
