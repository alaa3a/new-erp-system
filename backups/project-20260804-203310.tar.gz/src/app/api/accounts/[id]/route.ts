import { NextResponse } from 'next/server'
import { requireAuth } from '@/lib/auth/middleware'
import { accountRepository } from '@/lib/repositories/accountRepository'
import { auditLogRepository } from '@/lib/repositories/userRepository'
import { handleApiError, NotFoundError, ValidationError, ConflictError } from '@/lib/utils/errors'
import { ensureInitialized } from '@/lib/db'
import { validate, updateAccountSchema } from '@/lib/validators'

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureInitialized()
    const { id } = await params
    const account = accountRepository.findById(Number(id))
    if (!account) throw new NotFoundError('Account', id)
    return NextResponse.json({ success: true, data: account })
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireAuth(request)
    if (auth instanceof NextResponse) return auth
    await ensureInitialized()
    const { id } = await params
    const body = validate(updateAccountSchema, await request.json())
    const accountId = Number(id)
    const existing = accountRepository.findById(accountId)
    if (!existing) throw new NotFoundError('Account', id)

    // Handle toggle active with cascade
    if (body.action === 'toggleActive') {
      const active = body.isActive === true
      const updated = accountRepository.toggleActive(accountId, active, existing.version)
      if (!updated) throw new ConflictError('Account was modified by another user. Please refresh.')
      if (body.cascade) {
        accountRepository.cascadeToggleActive(accountId, active)
      }
      auditLogRepository.log({ userId: auth.userId, action: 'update', entityType: 'account', entityId: accountId, changes: { isActive: { from: !active, to: active } } })
      return NextResponse.json({ success: true })
    }

    // Handle link cost center
    if (body.action === 'linkCostCenter') {
      const updated = accountRepository.linkCostCenter(accountId, body.costCenterId ?? null, existing.version)
      if (!updated) throw new ConflictError('Account was modified by another user. Please refresh.')
      // Cascade the same cost center to all descendants (all levels)
      if (body.cascade) {
        const affectedSubAccounts = accountRepository.cascadeLinkCostCenter(accountId, body.costCenterId ?? null)
        if (affectedSubAccounts > 0) {
          auditLogRepository.log({
            userId: auth.userId,
            action: 'update',
            entityType: 'account',
            entityId: accountId,
            changes: {
              cascadeScope: { from: 'current_account_only', to: 'all_sub_accounts' },
              affectedSubAccounts: { from: 0, to: affectedSubAccounts },
              costCenterId: { from: existing.costCenterId, to: body.costCenterId ?? null },
            },
          })
        }
      }
      auditLogRepository.log({ userId: auth.userId, action: 'update', entityType: 'account', entityId: accountId, changes: { costCenterId: { from: existing.costCenterId, to: body.costCenterId ?? null } } })
      return NextResponse.json({ success: true })
    }

    // Normal update
    if (body.code && body.code !== existing.code) {
      const codeExists = accountRepository.findByCode(body.code)
      if (codeExists && codeExists.id !== accountId) {
        throw new ValidationError(`Account with code "${body.code}" already exists`)
      }
    }
    const nextPartnerRole = body.partnerRole !== undefined ? body.partnerRole : existing.partnerRole
    const updated = accountRepository.update(accountId, {
      code: body.code || existing.code,
      name: body.name || existing.name,
      type: body.type || existing.type,
      parentId: body.parentId !== undefined ? body.parentId : existing.parentId,
      partnerRole: nextPartnerRole,
      isActive: body.isActive !== undefined ? body.isActive : existing.isActive,
      description: body.description !== undefined ? body.description : existing.description,
    }, existing.version)
    if (!updated) throw new ConflictError('Account was modified by another user. Please refresh.')
    auditLogRepository.log({ userId: auth.userId, action: 'update', entityType: 'account', entityId: accountId })

    // AR/AP flag vs active-profile contradiction warning (§6.8) — non-blocking.
    let warning = ''
    if (nextPartnerRole !== existing.partnerRole) {
      const { asAr, asAp } = accountRepository.getActiveProfileRoles(existing.code)
      if (nextPartnerRole === 'ar' && asAp) {
        warning = `Account is used as Accounts Payable in an active posting profile; the "ar" flag may hide vendor partners on this account.`
      } else if (nextPartnerRole === 'ap' && asAr) {
        warning = `Account is used as Accounts Receivable in an active posting profile; the "ap" flag may hide customer partners on this account.`
      } else if (nextPartnerRole === 'none' && (asAr || asAp)) {
        warning = `Account is used as ${asAr ? 'Accounts Receivable' : 'Accounts Payable'} in an active posting profile. Set the flag to "${asAr ? 'ar' : 'ap'}" (or "both") to match.`
      }
    }
    return NextResponse.json({ success: true, warning: warning || undefined })
  } catch (error) {
    return handleApiError(error)
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const auth = await requireAuth(request)
    if (auth instanceof NextResponse) return auth
    await ensureInitialized()
    const { id } = await params
    const accountId = Number(id)
    const existing = accountRepository.findById(accountId)
    if (!existing) throw new NotFoundError('Account', id)
    if (existing.isSystemAccount) throw new ValidationError('Cannot delete a system account')
    if (accountRepository.hasChildren(accountId)) throw new ValidationError('Remove all child accounts first')
    if (accountRepository.isUsedInEntries(existing.code)) throw new ValidationError('Account has posted transactions')
    if (accountRepository.isUsedInInvoiceLines(existing.code)) throw new ValidationError('Account is referenced in invoices')
    if (accountRepository.isUsedInPostingProfiles(existing.code)) throw new ValidationError('Account is used in posting profiles')
    const deleted = accountRepository.hardDelete(accountId, existing.version)
    if (!deleted) throw new ConflictError('Account was modified by another user. Please refresh.')
    auditLogRepository.log({ userId: auth.userId, action: 'delete', entityType: 'account', entityId: accountId })
    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
