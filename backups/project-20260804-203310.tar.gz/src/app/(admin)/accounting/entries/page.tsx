'use client'
import { formatCurrency } from '@/lib/formatters'
import { ClearFiltersButton, StatusBadge, ModalHeader, SearchInput, StatCard, EmptyState } from '@/components/ui'
export const dynamic = 'force-dynamic'

import { useState, useEffect, useCallback, useMemo, Fragment, Suspense } from 'react'
import { usePagination } from '@/hooks/usePagination'
import {
  Plus, Eye, Edit3, Loader2, Trash2, ChevronDown,
  X, AlertTriangle, CheckCircle, FileText, Scale,
  ChevronUp, Percent, Receipt,
} from 'lucide-react'
import SearchSelect from '@/components/form/SearchSelect'
import DatePicker from '@/components/form/input/DatePicker'
import { Modal } from '@/components/ui/modal'
import Button from '@/components/ui/button/Button'
import { Pagination } from '@/components/Pagination'
import { useToast } from '@/components/ui/toast/ToastProvider'
import type {
  Entry, EntryLine, EntryStatus, Account, EntryCategory,
  EntryLineType, BusinessPartner, CostCenter, TaxCode, PostingProfile, Invoice,
} from '@/types/erp'

// ─── Constants ─────────────────────────────────────────────────────────

const statusStyles: Record<string, string> = {
  draft: 'bg-yellow-50 text-yellow-700 dark:bg-yellow-950/30 dark:text-yellow-400',
  posted: 'bg-green-50 text-green-700 dark:bg-green-950/30 dark:text-green-400',
  cancelled: 'bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-400',
}

const statusFilters = ['all', 'draft', 'posted', 'cancelled'] as const

const lineTypeOptions: EntryLineType[] = ['normal', 'tax', 'payment']
const lineTypeConfig: Record<EntryLineType, { label: string; bg: string; text: string }> = {
  normal: { label: 'Normal', bg: 'bg-gray-100 dark:bg-gray-800', text: 'text-gray-600 dark:text-gray-300' },
  tax: { label: 'Tax', bg: 'bg-amber-50 dark:bg-amber-950/50', text: 'text-amber-700 dark:text-amber-400' },
  payment: { label: 'Payment', bg: 'bg-blue-50 dark:bg-blue-950/50', text: 'text-blue-700 dark:text-blue-400' },
}

// ─── Types ──────────────────────────────────────────────────────────────

interface LineAllocationFormData {
  id: string
  invoiceId: number
  amount: number
  notes: string
}

interface LineFormData {
  id: string
  lineType: EntryLineType
  accountCode: string
  description: string
  debitAmount: number
  creditAmount: number
  costCenterId: number | null
  businessPartnerId: number | null
  vatCodeId: number | null
  vatAmount: number
  supplierName: string
  supplierTaxId: string
  invoiceNumber: string
  invoiceDate: string
  cashAccountCode: string
  allocations: LineAllocationFormData[]
}

interface EntryFormData {
  entryDate: string
  description: string
  referenceNumber: string
  entryCategoryId: number | null
  lines: LineFormData[]
}

// ─── Helpers ────────────────────────────────────────────────────────────

const emptyForm = (): EntryFormData => ({
  entryDate: new Date().toISOString().split('T')[0],
  description: '',
  referenceNumber: '',
  entryCategoryId: null,
  lines: [],
})

let _lineKey = 0
const nextLineId = () => `line_${++_lineKey}`

const newLine = (): LineFormData => ({
  id: nextLineId(),
  lineType: 'normal',
  accountCode: '',
  description: '',
  debitAmount: 0,
  creditAmount: 0,
  costCenterId: null,
  businessPartnerId: null,
  vatCodeId: null,
  vatAmount: 0,
  supplierName: '',
  supplierTaxId: '',
  invoiceNumber: '',
  invoiceDate: '',
  cashAccountCode: '',
  allocations: [],
})

// ─── Main Component ─────────────────────────────────────────────────────

export default function EntriesPage() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center py-20"><Loader2 className="w-6 h-6 text-brand-500 animate-spin" /><span className="ml-2 text-sm text-gray-500 dark:text-gray-400">Loading entries...</span></div>}>
      <EntriesPageContent />
    </Suspense>
  )
}

function EntriesPageContent() {
  const toast = useToast()
  // ── Data state ──
  const [entries, setEntries] = useState<Entry[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  // 'all' = no filter, otherwise a category id
  const [categoryFilter, setCategoryFilter] = useState<string>('all')
  const { page, pageSize, setFilterAndResetPage } = usePagination()

  // ── Reference data ──
  const [accounts, setAccounts] = useState<Account[]>([])
  const [categories, setCategories] = useState<EntryCategory[]>([])
  const [costCenters, setCostCenters] = useState<CostCenter[]>([])
  const [partners, setPartners] = useState<BusinessPartner[]>([])
  const [taxCodes, setTaxCodes] = useState<TaxCode[]>([])
  const [postingProfiles, setPostingProfiles] = useState<PostingProfile[]>([])
  const [openInvoices, setOpenInvoices] = useState<Record<number, Invoice[]>>({})
  const [loadingInvoices, setLoadingInvoices] = useState<number | null>(null)

  // ── Expandable rows ──
  const [expandedId, setExpandedId] = useState<number | null>(null)
  const [entryLines, setEntryLines] = useState<Record<number, EntryLine[]>>({})
  const [loadingLines, setLoadingLines] = useState<number | null>(null)

  // ── Form state ──
  const [showForm, setShowForm] = useState(false)
  const [editingEntry, setEditingEntry] = useState<Entry | null>(null)
  const [formData, setFormData] = useState<EntryFormData>(emptyForm())
  const [submitting, setSubmitting] = useState(false)
  const [formError, setFormError] = useState('')

  // ── Line editor modal state ──
  const [lineModalOpen, setLineModalOpen] = useState(false)
  const [draftLine, setDraftLine] = useState<LineFormData | null>(null)
  const [editingLineId, setEditingLineId] = useState<string | null>(null)
  const [lineModalError, setLineModalError] = useState('')

  // ── View detail ──
  const [viewEntry, setViewEntry] = useState<Entry | null>(null)
  const [viewLines, setViewLines] = useState<EntryLine[]>([])
  const [viewLoading, setViewLoading] = useState(false)

  // ── Post/Cancel confirmations ──
  const [postTarget, setPostTarget] = useState<Entry | null>(null)
  const [posting, setPosting] = useState(false)
  const [cancelTarget, setCancelTarget] = useState<Entry | null>(null)

  // ── Fetch entries ──
  const fetchEntries = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      params.set('page', String(page))
      params.set('pageSize', String(pageSize))
      if (statusFilter !== 'all') params.set('status', statusFilter)
      if (searchQuery) params.set('search', searchQuery)
      if (categoryFilter !== 'all') params.set('categoryId', categoryFilter)
      const res = await fetch(`/api/entries?${params}`)
      if (res.ok) { const json = await res.json(); if (json.success) { setEntries(json.data); setTotal(json.total) } }
    } catch (err) {
      console.error('Failed to fetch entries:', err)
    } finally {
      setLoading(false)
    }
  }, [page, pageSize, statusFilter, searchQuery, categoryFilter])

  // ── Fetch reference data ──
  const fetchRefData = useCallback(async () => {
    try {
      const [aRes, cRes, ccRes, pRes, tRes, ppRes] = await Promise.all([
        fetch('/api/accounts'), fetch('/api/entry-categories'), fetch('/api/cost-centers'),
        fetch('/api/partners'), fetch('/api/tax-codes'), fetch('/api/posting-profiles'),
      ])
      if (aRes.ok) { const json = await aRes.json(); if (json.success) setAccounts(json.data) }
      if (cRes.ok) { const json = await cRes.json(); if (json.success) setCategories(json.data) }
      if (ccRes.ok) { const json = await ccRes.json(); if (json.success) setCostCenters(json.data) }
      if (pRes.ok) { const json = await pRes.json(); if (json.success) setPartners(json.data) }
      if (tRes.ok) { const json = await tRes.json(); if (json.success) setTaxCodes(json.data) }
      if (ppRes.ok) { const json = await ppRes.json(); if (json.success) setPostingProfiles(json.data) }
    } catch (err) {
      console.error('Failed to fetch reference data:', err)
    }
  }, [])

  useEffect(() => { fetchEntries() }, [fetchEntries])
  useEffect(() => { fetchRefData() }, [fetchRefData])

  // ── Account options ──
  const accountOptions = useMemo(() => accounts
    .filter(a => a.isActive)
    .map(a => ({ id: a.code, label: `${a.code} — ${a.name} (${a.type})` })),
  [accounts])

  const accountMap = useMemo(() => {
    const map = new Map<string, Account>()
    for (const a of accounts) map.set(a.code, a)
    return map
  }, [accounts])

  // ── Category options ──
  const categoryOptions = useMemo(() => categories
    .filter(c => c.isActive)
    .map(c => ({ id: c.id, label: `${c.code} — ${c.name}` })),
  [categories])

  const categoryMap = useMemo(() => {
    const map = new Map<number, EntryCategory>()
    for (const c of categories) map.set(c.id, c)
    return map
  }, [categories])

  // ── Line-editor reference maps / options ──
  const costCenterMap = useMemo(() => {
    const map = new Map<number, CostCenter>()
    for (const c of costCenters) map.set(c.id, c)
    return map
  }, [costCenters])

  const partnerMap = useMemo(() => {
    const map = new Map<number, BusinessPartner>()
    for (const p of partners) map.set(p.id, p)
    return map
  }, [partners])

  const taxCodeMap = useMemo(() => {
    const map = new Map<number, TaxCode>()
    for (const t of taxCodes) map.set(t.id, t)
    return map
  }, [taxCodes])

  // Active, non-group tax types only — grouped by their tax group for the picker
  const taxTypeOptions = useMemo(() => {
    const groups = taxCodes.filter(t => t.isGroup)
    return taxCodes
      .filter(t => t.isActive && !t.isGroup)
      .map(t => ({
        id: t.id,
        label: `${t.code} — ${t.name} (${t.rate}%)`,
        groupLabel: groups.find(g => g.id === t.parentId)?.name || 'Other',
      }))
  }, [taxCodes])

  // Cost-center rule: when the selected account is linked to a cost center, show
  // that cost center + all descendants at every level; otherwise no options.
  const costCenterOptionsForAccount = useCallback((accountCode: string) => {
    const acct = accountMap.get(accountCode)
    if (!acct?.costCenterId) return []
    const seed = costCenters.find(c => c.id === acct.costCenterId)
    if (!seed) return []
    const result: CostCenter[] = []
    const seen = new Set<number>()
    const collect = (cc: CostCenter) => {
      if (seen.has(cc.id)) return
      seen.add(cc.id)
      result.push(cc)
      for (const child of costCenters) if (child.parentId === cc.id) collect(child)
    }
    collect(seed)
    return result
  }, [accountMap, costCenters])

  // AR/AP detection: the account's own partnerRole flag wins, then the active
  // posting-profile fallback, default both (§6.8 precedence).
  const partnerRoleForAccount = useCallback((accountCode: string): 'ar' | 'ap' | 'both' => {
    const acct = accountMap.get(accountCode)
    if (acct && acct.partnerRole && acct.partnerRole !== 'none') return acct.partnerRole
    const active = postingProfiles.filter(p => p.isActive)
    const asAr = active.some(p => p.accountsReceivableCode === accountCode)
    const asAp = active.some(p => p.accountsPayableCode === accountCode)
    if (asAr && asAp) return 'both'
    if (asAr) return 'ar'
    if (asAp) return 'ap'
    return 'both'
  }, [accountMap, postingProfiles])

  const resolveControlAccount = useCallback((partner: BusinessPartner): string => {
    const active = postingProfiles.filter(p => p.isActive)
    if (partner.type === 'vendor') return active.find(p => p.accountsPayableCode)?.accountsPayableCode || '201'
    return active.find(p => p.accountsReceivableCode)?.accountsReceivableCode || '102'
  }, [postingProfiles])

  const resolveCashAccount = useCallback((): string => {
    const active = postingProfiles.filter(p => p.isActive)
    return active.find(p => p.cashAccountCode)?.cashAccountCode || '101'
  }, [postingProfiles])

  const partnerOptionsForRole = useCallback((role: 'ar' | 'ap' | 'both') =>
    partners
      .filter(p => p.status === 'active' && (
        role === 'both'
        || (role === 'ar' ? (p.type === 'customer' || p.type === 'both') : (p.type === 'vendor' || p.type === 'both'))
      ))
      .map(p => ({ id: p.id, label: `${p.code} — ${p.name}` })),
  [partners])

  // Open invoices for the payment-line card (cached per partner; force skips the cache)
  const fetchOpenInvoices = useCallback(async (partnerId: number, force = false) => {
    if (!force && openInvoices[partnerId]) return
    setLoadingInvoices(partnerId)
    try {
      const res = await fetch(`/api/invoices?businessPartnerId=${partnerId}&open=1&pageSize=50`)
      if (res.ok) {
        const json = await res.json()
        if (json.success) setOpenInvoices(prev => ({ ...prev, [partnerId]: json.data }))
      }
    } catch (err) {
      console.error('Failed to fetch open invoices:', err)
    } finally {
      setLoadingInvoices(null)
    }
  }, [openInvoices])

  // ── Filtered list ──
  const filtered = useMemo(() => entries.filter(e => {
    if (statusFilter !== 'all' && e.status !== statusFilter) return false
    if (categoryFilter !== 'all' && e.categoryId !== Number(categoryFilter)) return false
    if (searchQuery) {
      const q = searchQuery.toLowerCase()
      return e.entryNumber.toLowerCase().includes(q) || e.description.toLowerCase().includes(q)
    }
    return true
  }), [entries, statusFilter, searchQuery, categoryFilter])

  // ── Summary ──
  const totalDebit = useMemo(() => filtered.reduce((s, e) => s + e.totalDebit, 0), [filtered])
  const totalCredit = useMemo(() => filtered.reduce((s, e) => s + e.totalCredit, 0), [filtered])
  const isBalanced = totalDebit === totalCredit

  // ── Form line totals ──
  const formTotals = useMemo(() => {
    let d = 0, c = 0
    for (const line of formData.lines) {
      d += line.debitAmount
      c += line.creditAmount
    }
    return { debit: d, credit: c, balanced: d === c }
  }, [formData.lines])

  // ── Expand row ──
  const toggleExpand = async (entryId: number) => {
    if (entryLines[entryId]) {
      setExpandedId(expandedId === entryId ? null : entryId)
      return
    }
    setLoadingLines(entryId)
    try {
      const res = await fetch(`/api/entries/${entryId}`)
      if (res.ok) {
        const json = await res.json()
        if (json.success) setEntryLines(prev => ({ ...prev, [entryId]: json.data.lines ?? [] }))
      }
    } catch (err) {
      console.error('Failed to fetch entry lines:', err)
    } finally {
      setLoadingLines(null)
      setExpandedId(expandedId === entryId ? null : entryId)
    }
  }

  // ── Form helpers ──
  const openAddForm = () => {
    setEditingEntry(null)
    setFormData(emptyForm())
    setFormError('')
    setShowForm(true)
  }

  const openEditForm = async (entry: Entry) => {
    setEditingEntry(entry)
    setFormError('')
    setFormData({
      entryDate: entry.entryDate,
      description: entry.description,
      referenceNumber: entry.referenceNumber,
      entryCategoryId: entry.categoryId,
      lines: [],
    })

    try {
      const res = await fetch(`/api/entries/${entry.id}`)
      if (res.ok) {
        const json = await res.json()
        if (json.success && json.data.lines) {
          setFormData(prev => ({
            ...prev,
            lines: json.data.lines.map((l: EntryLine & { allocations?: { id: number; invoiceId: number; amount: number; notes: string }[] }) => ({
              id: nextLineId(),
              lineType: l.lineType || 'normal',
              accountCode: l.accountCode,
              description: l.description || '',
              debitAmount: Math.round(l.debitAmount / 100),
              creditAmount: Math.round(l.creditAmount / 100),
              costCenterId: l.costCenterId,
              businessPartnerId: l.businessPartnerId,
              vatCodeId: l.vatCodeId,
              vatAmount: Math.round(l.vatAmount / 100),
              supplierName: l.supplierName || '',
              supplierTaxId: l.supplierTaxId || '',
              invoiceNumber: l.invoiceNumber || '',
              invoiceDate: l.invoiceDate || '',
              cashAccountCode: '',
              allocations: (l.allocations || []).map(a => ({
                id: nextLineId(),
                invoiceId: a.invoiceId,
                amount: Math.round(a.amount / 100),
                notes: a.notes || '',
              })),
            })),
          }))
        }
      }
    } catch (err) {
      console.error('Failed to fetch entry lines:', err)
    }
    setShowForm(true)
  }

  const closeForm = () => {
    setShowForm(false)
    setEditingEntry(null)
    setFormError('')
  }

  const addLine = () => {
    // Open the line-editor modal with a fresh line instead of inserting an inline card.
    setDraftLine(newLine())
    setEditingLineId(null)
    setLineModalOpen(true)
  }

  const editLine = (id: string) => {
    const line = formData.lines.find(l => l.id === id)
    if (!line) return
    setDraftLine({ ...line, allocations: line.allocations.map(a => ({ ...a })) })
    setEditingLineId(id)
    setLineModalOpen(true)
  }

  const closeLineModal = () => {
    setLineModalOpen(false)
    setDraftLine(null)
    setEditingLineId(null)
  }

  const saveLineFromModal = () => {
    if (!draftLine) return
    if (draftLine.lineType !== 'normal' && !draftLine.accountCode) {
      setFormError('Complete the tax/payment line (click Generate) or choose a different type')
      return
    }
    if (!draftLine.accountCode) {
      setFormError('Every line must have an account selected')
      return
    }
    setFormData(prev => {
      if (editingLineId) {
        return {
          ...prev,
          lines: prev.lines.map(l => l.id === editingLineId ? draftLine : l),
        }
      }
      return { ...prev, lines: [...prev.lines, draftLine] }
    })
    setFormError('')
    closeLineModal()
  }

  const removeLine = (id: string) => {
    setFormData(prev => ({ ...prev, lines: prev.lines.filter(l => l.id !== id) }))
  }

  const updateDraftLine = (updates: Partial<LineFormData>) => {
    setDraftLine(prev => prev ? { ...prev, ...updates } : prev)
  }

  const updateDraftAllocation = (invoiceId: number, updates: Partial<LineAllocationFormData>) => {
    setDraftLine(prev => {
      if (!prev) return prev
      const exists = prev.allocations.some(a => a.invoiceId === invoiceId)
      return {
        ...prev,
        allocations: exists
          ? prev.allocations.map(a => a.invoiceId === invoiceId ? { ...a, ...updates } : a)
          : [...prev.allocations, { id: nextLineId(), invoiceId, amount: 0, notes: '', ...updates }],
      }
    })
  }

  const removeDraftAllocation = (invoiceId: number) => {
    setDraftLine(prev => prev
      ? { ...prev, allocations: prev.allocations.filter(a => a.invoiceId !== invoiceId) }
      : prev)
  }

  // Tax-line generation (modal draft): converts the generator card into the computed tax line.
  const generateTaxLineDraft = () => {
    setDraftLine(prev => {
      if (!prev || !prev.vatCodeId) return prev
      const tax = taxCodeMap.get(prev.vatCodeId)
      if (!tax) return prev
      const base = Math.max(prev.debitAmount, prev.creditAmount, 0)
      const amount = Math.round(base * tax.rate) / 100
      const isDebit = tax.type === 'input'
      return {
        ...prev,
        lineType: 'tax',
        accountCode: tax.accountCode,
        description: prev.description || `${tax.code} — ${tax.name}`,
        debitAmount: isDebit ? amount : 0,
        creditAmount: isDebit ? 0 : amount,
        vatAmount: amount,
      }
    })
  }

  // Payment-line generation (modal draft): materializes the payment (AR/AP clearing)
  // + optional WHT tax + cash lines directly into the entry, replacing the generator card.
  const generatePaymentLinesDraft = () => {
    if (!draftLine) return
    const card = draftLine
    const partner = card.businessPartnerId ? partnerMap.get(card.businessPartnerId) : undefined
    const total = card.allocations.reduce((s, a) => s + (a.amount || 0), 0)
    if (total <= 0 || !partner || !card.accountCode || !card.cashAccountCode) {
      setFormError('Complete partner, account, cash account and at least one allocation before generating')
      return
    }

    const role = partnerRoleForAccount(card.accountCode)
    const isAp = role === 'ap' || (role === 'both' && partner.type === 'vendor')
    const whtCode = card.vatCodeId ? taxCodeMap.get(card.vatCodeId) : undefined
    const whtAmount = whtCode ? Math.round(total * whtCode.rate) / 100 : 0
    const cash = Math.round((total - whtAmount) * 100) / 100

    const generated: LineFormData[] = [{
      ...newLine(),
      lineType: 'payment',
      accountCode: card.accountCode,
      description: `Payment — ${partner.name}`,
      debitAmount: isAp ? total : 0,
      creditAmount: isAp ? 0 : total,
      businessPartnerId: partner.id,
      supplierName: partner.name,
      supplierTaxId: partner.taxRegistrationNumber || '',
      allocations: card.allocations,
    }]

    if (whtCode && whtAmount > 0) {
      generated.push({
        ...newLine(),
        lineType: 'tax',
        accountCode: whtCode.accountCode,
        description: `${whtCode.code} — ${whtCode.name}`,
        debitAmount: isAp ? 0 : whtAmount,
        creditAmount: isAp ? whtAmount : 0,
        vatCodeId: whtCode.id,
        vatAmount: whtAmount,
        supplierName: partner.name,
        supplierTaxId: partner.taxRegistrationNumber || '',
        invoiceNumber: card.invoiceNumber,
        invoiceDate: card.invoiceDate,
      })
    }

    generated.push({
      ...newLine(),
      accountCode: card.cashAccountCode,
      description: `Cash — ${partner.name}`,
      debitAmount: isAp ? 0 : cash,
      creditAmount: isAp ? cash : 0,
    })

    setFormData(prev => ({
      ...prev,
      lines: editingLineId
        ? [...prev.lines.filter(l => l.id !== editingLineId), ...generated]
        : [...prev.lines, ...generated],
    }))
    setFormError('')
    closeLineModal()
  }

  const handleSave = async () => {
    setSubmitting(true)
    setFormError('')

    if (!formData.description.trim()) {
      setFormError('Description is required')
      setSubmitting(false)
      return
    }
    if (formData.lines.length === 0) {
      setFormError('At least one line item is required')
      setSubmitting(false)
      return
    }
    if (!formTotals.balanced) {
      setFormError(`Entry is not balanced. Debit: ${formTotals.debit}, Credit: ${formTotals.credit}`)
      setSubmitting(false)
      return
    }

    // Tax / payment generator cards must be completed (Generate) or removed first
    const pendingGenerator = formData.lines.find(l => l.lineType !== 'normal' && !l.accountCode)
    if (pendingGenerator) {
      setFormError('Complete the tax/payment line (click Generate) or remove it before saving')
      setSubmitting(false)
      return
    }
    // Validate each line has an account
    const emptyLine = formData.lines.find(l => !l.accountCode)
    if (emptyLine) {
      setFormError('Every line must have an account selected')
      setSubmitting(false)
      return
    }

    try {
      const body = {
        entryDate: formData.entryDate,
        description: formData.description.trim(),
        referenceNumber: formData.referenceNumber.trim(),
        entryCategoryId: formData.entryCategoryId,
        lines: formData.lines.map(l => ({
          accountCode: l.accountCode,
          description: l.description || formData.description.trim(),
          debitAmount: Math.round(l.debitAmount * 100),
          creditAmount: Math.round(l.creditAmount * 100),
          lineType: l.lineType,
          costCenterId: l.costCenterId,
          businessPartnerId: l.businessPartnerId,
          vatCodeId: l.vatCodeId,
          vatAmount: Math.round(l.vatAmount * 100),
          supplierName: l.supplierName || null,
          supplierTaxId: l.supplierTaxId || null,
          invoiceNumber: l.invoiceNumber || null,
          invoiceDate: l.invoiceDate || null,
          allocations: l.allocations.map(a => ({
            invoiceId: a.invoiceId,
            amount: Math.round(a.amount * 100),
            notes: a.notes || '',
          })),
        })),
      }

      if (editingEntry) {
        const res = await fetch(`/api/entries/${editingEntry.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...body, version: editingEntry.version }),
        })
        if (!res.ok) {
          const err = await res.json()
          throw new Error(err.error || 'Failed to update entry')
        }
      } else {
        const res = await fetch('/api/entries', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        })
        if (!res.ok) {
          const err = await res.json()
          throw new Error(err.error || 'Failed to create entry')
        }
      }

      closeForm()
      await fetchEntries()
      toast.success(editingEntry ? `Entry "${formData.description}" updated` : `Entry "${formData.description}" created`)
    } catch (err: any) {
      setFormError(err?.message || 'An error occurred')
      toast.error(err?.message || 'Failed to save entry')
    } finally {
      setSubmitting(false)
    }
  }

  // ── View entry detail ──
  const openViewDetail = async (entry: Entry) => {
    setViewEntry(entry)
    setViewLoading(true)
    try {
      const res = await fetch(`/api/entries/${entry.id}`)
      if (res.ok) {
        const json = await res.json()
        if (json.success) setViewLines(json.data.lines || [])
      } else {
        setViewLines([])
      }
    } catch (err) {
      console.error('Failed to fetch entry detail:', err)
      setViewLines([])
    } finally {
      setViewLoading(false)
    }
  }

  // ── Post entry ──
  const handlePost = async () => {
    if (!postTarget) return
    setPosting(true)
    try {
      const res = await fetch(`/api/entries/${postTarget.id}/post`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'post' }),
      })
      if (!res.ok) {
        const err = await res.json()
        throw new Error(err.error || 'Failed to post entry')
      }
      setPostTarget(null)
      await fetchEntries()
      toast.success(`Entry ${postTarget.entryNumber} posted`)
    } catch (err: any) {
      toast.error(err?.message || 'Failed to post entry')
    } finally {
      setPosting(false)
    }
  }

  // ── Cancel entry ──
  const handleCancel = async () => {
    if (!cancelTarget) return
    try {
      const res = await fetch(`/api/entries/${cancelTarget.id}/post`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'cancel' }),
      })
      if (!res.ok) {
        const err = await res.json()
        throw new Error(err.error || 'Failed to cancel entry')
      }
      setCancelTarget(null)
      await fetchEntries()
      toast.success(`Entry ${cancelTarget.entryNumber} cancelled`)
    } catch (err: any) {
      toast.error(err?.message || 'Failed to cancel entry')
    }
  }

  // ── Render ──
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Journal Entries</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Record and manage journal entries with balanced debit/credit lines.
          </p>
        </div>
        <button onClick={openAddForm}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-brand-500 text-white text-sm font-medium hover:bg-brand-600 transition-colors shadow-sm">
          <Plus className="w-4 h-4" /> New Entry
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total Entries', value: filtered.length.toString(), color: 'text-gray-900 dark:text-white' },
          { label: 'Total Debit', value: formatCurrency(totalDebit), color: 'text-brand-500' },
          { label: 'Total Credit', value: formatCurrency(totalCredit), color: 'text-amber-500' },
          {
            label: 'Balance',
            value: isBalanced ? 'Balanced' : `$${Math.abs(totalDebit - totalCredit) / 100}`,
            color: isBalanced ? 'text-green-500' : 'text-red-500',
          },
        ].map(s => (
          <StatCard key={s.label} label={s.label} value={s.value} color={s.color} />
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 px-4 py-2.5">
        {statusFilters.map(f => (
          <button key={f} onClick={() => setFilterAndResetPage(setStatusFilter, f)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium capitalize transition-colors ${
              statusFilter === f
                ? 'bg-brand-50 text-brand-600 dark:bg-brand-950/30 dark:text-brand-400 shadow-sm'
                : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}>
            {f === 'all' ? 'All' : f}
          </button>
        ))}
        <div className="flex items-center gap-1.5">
          <select value={categoryFilter} onChange={e => setFilterAndResetPage(setCategoryFilter, e.target.value)}
            className="rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 px-2.5 py-1.5 text-sm text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 transition-all">
            <option value="all">All categories</option>
            {categories.map(c => (
              <option key={c.id} value={c.id}>{c.code} — {c.name}</option>
            ))}
          </select>
        </div>
        <div className="flex-1 min-w-0" />
        <ClearFiltersButton
          compact
          filters={{
            status: statusFilter !== 'all',
            category: categoryFilter !== 'all',
            search: searchQuery !== '',
          }}
          onClear={() => {
            setFilterAndResetPage(setStatusFilter, 'all')
            setFilterAndResetPage(setCategoryFilter, 'all')
            setFilterAndResetPage(setSearchQuery, '')
          }}
        />
        <SearchInput value={searchQuery} onChange={v => setFilterAndResetPage(setSearchQuery, v)} placeholder="Search entries..." className="max-w-xs w-full" compact />
      </div>

      {/* Entry table */}
      <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 overflow-hidden">
        <div className="overflow-x-auto">
          {loading ? (
            <EmptyState icon={<Loader2 className="w-6 h-6 text-brand-500 animate-spin mb-3" />} title="Loading entries..." />
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-gray-900/50">
                  <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Entry #</th>
                  <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Date</th>
                  <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Category</th>
                  <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Description</th>
                  <th className="text-right py-3 px-4 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Debit</th>
                  <th className="text-right py-3 px-4 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Credit</th>
                  <th className="text-center py-3 px-4 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Status</th>
                  <th className="text-right py-3 px-4 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={8}>
                      <EmptyState
                        compact
                        icon={<FileText className="w-10 h-10 mx-auto text-gray-300 dark:text-gray-600 mb-2" />}
                        title={searchQuery || statusFilter !== 'all' || categoryFilter !== 'all' ? 'No entries match your filters' : 'No journal entries yet'}
                        action={!searchQuery && statusFilter === 'all' && categoryFilter === 'all' ? (
                          <button onClick={openAddForm} className="mt-2 text-sm font-medium text-brand-500 hover:text-brand-600">
                            <Plus className="w-4 h-4 inline" /> Create your first entry
                          </button>
                        ) : undefined}
                      />
                    </td>
                  </tr>
                ) : (
                  filtered.map(entry => (
                    <Fragment key={entry.id}>
                      <tr className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                        <td className="py-3 px-4 text-sm font-mono font-medium text-brand-600 dark:text-brand-400">
                          {entry.entryNumber}
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-500 dark:text-gray-400">{entry.entryDate}</td>
                        <td className="py-3 px-4">
                          {entry.categoryId && categoryMap.has(entry.categoryId) ? (
                            <span className="inline-flex items-center gap-1.5 text-xs font-medium px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-400">
                              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                              {categoryMap.get(entry.categoryId)!.name}
                            </span>
                          ) : (
                            <span className="text-xs text-gray-300 dark:text-gray-600">—</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-900 dark:text-white max-w-[200px] truncate">
                          {entry.description}
                        </td>
                        <td className="py-3 px-4 text-sm text-right font-medium text-gray-900 dark:text-white">
                          {formatCurrency(entry.totalDebit)}
                        </td>
                        <td className="py-3 px-4 text-sm text-right font-medium text-gray-900 dark:text-white">
                          {formatCurrency(entry.totalCredit)}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <StatusBadge label={entry.status.charAt(0).toUpperCase() + entry.status.slice(1)} color={statusStyles[entry.status]} />
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button onClick={() => openViewDetail(entry)}
                              className="p-1.5 rounded-lg text-gray-400 hover:text-brand-500 hover:bg-brand-50 dark:hover:bg-brand-950/30 transition-colors"
                              title="View detail"><Eye className="w-3.5 h-3.5" /></button>
                            {entry.status === 'draft' && (
                              <>
                                <button onClick={() => openEditForm(entry)}
                                  className="p-1.5 rounded-lg text-gray-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors"
                                  title="Edit"><Edit3 className="w-3.5 h-3.5" /></button>
                                <button onClick={() => setPostTarget(entry)}
                                  className="p-1.5 rounded-lg text-gray-400 hover:text-green-500 hover:bg-green-50 dark:hover:bg-green-950/30 transition-colors"
                                  title="Post"><CheckCircle className="w-3.5 h-3.5" /></button>
                                <button onClick={() => setCancelTarget(entry)}
                                  className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                                  title="Cancel"><X className="w-3.5 h-3.5" /></button>
                              </>
                            )}
                            <button onClick={() => toggleExpand(entry.id)}
                              aria-expanded={expandedId === entry.id}
                              aria-label={expandedId === entry.id ? 'Collapse lines' : 'Expand lines'}
                              className={`p-1.5 rounded-lg transition-colors ${
                                expandedId === entry.id
                                  ? 'text-brand-500 hover:bg-brand-50 dark:hover:bg-brand-950/30'
                                  : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                              }`}
                              title={expandedId === entry.id ? 'Collapse lines' : 'Expand lines'}>
                              {expandedId === entry.id ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        </td>
                      </tr>
                      {/* Expanded lines */}
                      {expandedId === entry.id && (
                        <>
                          {loadingLines === entry.id ? (
                            <tr className="bg-gray-50/50 dark:bg-gray-800/30">
                              <td colSpan={8} className="py-3 px-4 text-center">
                                <Loader2 className="w-4 h-4 text-brand-500 animate-spin mx-auto" />
                              </td>
                            </tr>
                          ) : (
                            (entryLines[entry.id] ?? []).map(line => {
                              const acct = accountMap.get(line.accountCode)
                              const lineCc = line.costCenterId ? costCenterMap.get(line.costCenterId) : undefined
                              const linePartner = line.businessPartnerId ? partnerMap.get(line.businessPartnerId) : undefined
                              const lineType = lineTypeConfig[line.lineType || 'normal']
                              return (
                                <tr key={line.id} className="bg-gray-50/50 dark:bg-gray-800/30">
                                  <td className="py-2 px-4 text-xs text-gray-400">L{line.lineNumber}</td>
                                  <td className="py-2 px-4">
                                    <div className="flex flex-wrap items-center gap-1">
                                      <span className={`inline-flex items-center text-[10px] font-medium px-1.5 py-0.5 rounded-full ${lineType.bg} ${lineType.text}`}>
                                        {lineType.label}
                                      </span>
                                      {lineCc && (
                                        <span className="inline-flex items-center text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-indigo-50 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400">
                                          CC: {lineCc.code}
                                        </span>
                                      )}
                                      {linePartner && (
                                        <span className="inline-flex items-center text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-600 dark:bg-emerald-950/50 dark:text-emerald-400">
                                          {linePartner.type === 'vendor' ? 'Supplier' : 'Customer'}: {linePartner.name}
                                        </span>
                                      )}
                                    </div>
                                  </td>
                                  <td className="py-2 px-4 text-sm font-mono text-gray-700 dark:text-gray-300">
                                    {line.accountCode}
                                    {acct && <span className="text-xs text-gray-400 ml-1">({acct.name})</span>}
                                  </td>
                                  <td className="py-2 px-4 text-sm text-gray-700 dark:text-gray-300">{line.description}</td>
                                  <td className="py-2 px-4 text-sm text-right text-green-600 dark:text-green-400">
                                    {line.debitAmount > 0 ? formatCurrency(line.debitAmount) : '—'}
                                  </td>
                                  <td className="py-2 px-4 text-sm text-right text-red-600 dark:text-red-400">
                                    {line.creditAmount > 0 ? formatCurrency(line.creditAmount) : '—'}
                                  </td>
                                  <td colSpan={2} />
                                </tr>
                              )
                            })
                          )}
                          {(entryLines[entry.id] ?? []).length === 0 && loadingLines !== entry.id && (
                            <tr className="bg-gray-50/50 dark:bg-gray-800/30">
                              <td colSpan={8} className="py-4 text-center text-sm text-gray-400">No line items</td>
                            </tr>
                          )}
                        </>
                      )}
                    </Fragment>
                  ))
                )}
              </tbody>
            </table>
          )}
        </div>
        <Pagination page={page} pageSize={pageSize} total={total} />
      </div>

      {/* ═══════════════════════════════════════════════════════════════════
          CREATE / EDIT ENTRY MODAL
         ═══════════════════════════════════════════════════════════════════ */}
      <Modal isOpen={showForm} onClose={closeForm} className="max-w-4xl p-0" showCloseButton={false}>
        <ModalHeader title={editingEntry ? `Edit Entry ${editingEntry.entryNumber}` : 'New Journal Entry'} onClose={closeForm} />

        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* ── Header Fields ── */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Entry Date *</label>
              <DatePicker value={formData.entryDate} onChange={(v) => setFormData(prev => ({ ...prev, entryDate: v }))} />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Reference #</label>
              <input type="text" value={formData.referenceNumber}
                onChange={e => setFormData(prev => ({ ...prev, referenceNumber: e.target.value }))}
                placeholder="Optional ref"
                className="w-full rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 px-3 py-2 text-sm text-gray-900 dark:text-white placeholder:text-gray-400" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Description *</label>
            <input type="text" value={formData.description}
              onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Entry description"
              className="w-full rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 px-3 py-2 text-sm text-gray-900 dark:text-white placeholder:text-gray-400" />
          </div>

          <div className="max-w-sm">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Category</label>
            <SearchSelect
              options={categoryOptions}
              value={formData.entryCategoryId}
              onChange={(val) => setFormData(prev => ({ ...prev, entryCategoryId: val ? Number(val) : null }))}
              placeholder="Select category (optional)..."
              noneLabel="No category"
              searchPlaceholder="Search categories..."
              notFoundLabel="No categories found"
            />
            {formData.entryCategoryId && categoryMap.has(formData.entryCategoryId) && (
              <p className="mt-1.5 text-[11px] text-gray-400 dark:text-gray-500">
                Numbered as <span className="font-mono">JE-{categoryMap.get(formData.entryCategoryId)!.code.replace(/[^A-Za-z0-9]/g, '').toUpperCase() || 'GEN'}-NNNNNN</span>
              </p>
            )}
          </div>

          {/* ── Line Items ── */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-semibold text-gray-900 dark:text-white">Line Items</h4>
              <button type="button" onClick={addLine}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-brand-50 text-brand-600 dark:bg-brand-950/30 dark:text-brand-400 text-xs font-medium hover:bg-brand-100 dark:hover:bg-brand-950/50 transition-colors">
                <Plus className="w-3.5 h-3.5" /> Add Line
              </button>
            </div>

            {/* Balance indicator */}
            {formData.lines.length > 0 && (
              <div className={`flex items-center gap-1.5 mb-3 px-3 py-2 rounded-lg text-xs font-medium ${
                formTotals.balanced
                  ? 'bg-green-50 text-green-700 dark:bg-green-950/30 dark:text-green-400'
                  : 'bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-400'
              }`}>
                <Scale className="w-3.5 h-3.5" />
                {formTotals.balanced
                  ? `Balanced: $${formTotals.debit.toFixed(2)} = $${formTotals.credit.toFixed(2)}`
                  : `Not balanced: Debit $${formTotals.debit.toFixed(2)} vs Credit $${formTotals.credit.toFixed(2)} (Diff: $${Math.abs(formTotals.debit - formTotals.credit).toFixed(2)})`
                }
              </div>
            )}

            {formData.lines.length === 0 ? (
              <div className="rounded-xl border-2 border-dashed border-gray-200 dark:border-gray-700 p-8 text-center">
                <FileText className="w-8 h-8 mx-auto text-gray-300 dark:text-gray-600 mb-2" />
                <p className="text-sm text-gray-400 dark:text-gray-500">No line items yet. Click "Add Line" to add debit/credit lines.</p>
              </div>
            ) : (
              <div className="rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 dark:bg-gray-800/50 border-b border-gray-200 dark:border-gray-700">
                      <th className="text-left py-2 px-3 text-xs font-medium text-gray-500 dark:text-gray-400">#</th>
                      <th className="text-left py-2 px-3 text-xs font-medium text-gray-500 dark:text-gray-400">Type</th>
                      <th className="text-left py-2 px-3 text-xs font-medium text-gray-500 dark:text-gray-400">Account</th>
                      <th className="text-left py-2 px-3 text-xs font-medium text-gray-500 dark:text-gray-400">Description</th>
                      <th className="text-right py-2 px-3 text-xs font-medium text-gray-500 dark:text-gray-400">Debit</th>
                      <th className="text-right py-2 px-3 text-xs font-medium text-gray-500 dark:text-gray-400">Credit</th>
                      <th className="text-right py-2 px-3 text-xs font-medium text-gray-500 dark:text-gray-400">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                    {formData.lines.map((line, idx) => {
                      const acct = line.accountCode ? accountMap.get(line.accountCode) : undefined
                      const t = lineTypeConfig[line.lineType] || lineTypeConfig.normal
                      return (
                        <tr key={line.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30">
                          <td className="py-2 px-3 text-xs text-gray-400">{idx + 1}</td>
                          <td className="py-2 px-3">
                            <span className={`inline-flex items-center text-[10px] font-medium px-1.5 py-0.5 rounded-full ${t.bg} ${t.text}`}>{t.label}</span>
                          </td>
                          <td className="py-2 px-3 text-xs font-mono font-medium text-gray-900 dark:text-white">
                            {line.accountCode}
                            {acct && <span className="text-gray-400 ml-1">({acct.name})</span>}
                          </td>
                          <td className="py-2 px-3 text-xs text-gray-600 dark:text-gray-300">{line.description}</td>
                          <td className="py-2 px-3 text-xs text-right font-medium text-green-600 dark:text-green-400">
                            {line.debitAmount > 0 ? formatCurrency(Math.round(line.debitAmount * 100)) : '—'}
                          </td>
                          <td className="py-2 px-3 text-xs text-right font-medium text-red-600 dark:text-red-400">
                            {line.creditAmount > 0 ? formatCurrency(Math.round(line.creditAmount * 100)) : '—'}
                          </td>
                          <td className="py-2 px-3 text-right">
                            <div className="flex items-center justify-end gap-1">
                              <button type="button" onClick={() => editLine(line.id)}
                                className="p-1 rounded-md text-gray-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors"
                                title="Edit line"><Edit3 className="w-3.5 h-3.5" /></button>
                              <button type="button" onClick={() => removeLine(line.id)}
                                className="p-1 rounded-md text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                                title="Remove line"><Trash2 className="w-3.5 h-3.5" /></button>
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Form error */}
          {formError && (
            <div className="rounded-lg bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 px-4 py-2.5">
              <p className="text-sm text-red-700 dark:text-red-400">{formError}</p>
            </div>
          )}
        </div>

        {/* Form footer */}
        <div className="p-6 border-t border-gray-200 dark:border-gray-700 flex items-center justify-end gap-3 bg-gray-50 dark:bg-gray-900/50 rounded-b-3xl">
          <Button variant="outline" size="sm" onClick={closeForm} disabled={submitting}>Cancel</Button>
          <Button size="sm" onClick={handleSave} disabled={submitting || !formTotals.balanced || formData.lines.length === 0}
            className="flex items-center gap-2">
            {submitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
            {editingEntry ? 'Update Entry' : 'Create Entry'}
          </Button>
        </div>
      </Modal>

      {/* ═══════════════════════════════════════════════════════════════════
          LINE EDITOR MODAL
         ═══════════════════════════════════════════════════════════════════ */}
      <Modal isOpen={lineModalOpen && !!draftLine} onClose={closeLineModal} className="max-w-3xl p-0" showCloseButton={false}>
        <ModalHeader title={editingLineId ? `Edit Line #${formData.lines.findIndex(l => l.id === editingLineId) + 1 || ''}` : 'Add Line'} onClose={closeLineModal} />

        <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {draftLine && (
            <>
              {/* Type selector */}
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-gray-500 dark:text-gray-400">Line type</span>
                <div className="flex items-center gap-0.5 rounded-lg bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 p-0.5">
                  {lineTypeOptions.map(t => (
                    <button key={t} type="button"
                      onClick={() => {
                        const updates: Partial<LineFormData> = { lineType: t }
                        if (t !== 'normal') updates.accountCode = ''
                        if (t === 'payment' && !draftLine.cashAccountCode) updates.cashAccountCode = resolveCashAccount()
                        updateDraftLine(updates)
                      }}
                      className={`px-2.5 py-1 rounded-md text-xs font-medium capitalize transition-colors ${
                        draftLine.lineType === t
                          ? 'bg-brand-50 text-brand-600 dark:bg-brand-950/30 dark:text-brand-400'
                          : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'
                      }`}>
                      {lineTypeConfig[t].label}
                    </button>
                  ))}
                </div>
              </div>

              {(() => {
                const isGenerator = draftLine.lineType !== 'normal' && !draftLine.accountCode
                const acct = draftLine.accountCode ? accountMap.get(draftLine.accountCode) : undefined
                const lineCcOptions = draftLine.accountCode ? costCenterOptionsForAccount(draftLine.accountCode) : []
                const role = draftLine.accountCode ? partnerRoleForAccount(draftLine.accountCode) : 'both'
                const cardPartners = partnerOptionsForRole(role)
                const allocTotal = draftLine.allocations.reduce((s, a) => s + (a.amount || 0), 0)
                const invoices = draftLine.businessPartnerId ? (openInvoices[draftLine.businessPartnerId] || []) : []
                const invoiceBalanceSum = invoices.reduce((s, inv) => s + (inv.totalAmount - inv.paidAmount) / 100, 0)
                const overAllocated = allocTotal > invoiceBalanceSum + 0.005
                const selectedTax = draftLine.vatCodeId ? taxCodeMap.get(draftLine.vatCodeId) : undefined

                if (isGenerator && draftLine.lineType === 'tax') {
                  return (
                    /* ── Tax generator card ── */
                    <div className="space-y-2 rounded-xl border border-dashed border-amber-300 dark:border-amber-700 bg-amber-50/40 dark:bg-amber-950/10 p-3">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2">
                        <div className="lg:col-span-5">
                          <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Tax Type *</label>
                          <SearchSelect
                            options={taxTypeOptions}
                            value={draftLine.vatCodeId}
                            onChange={(val) => updateDraftLine({ vatCodeId: val ? Number(val) : null })}
                            placeholder="Select tax type..."
                            searchPlaceholder="Search tax types..."
                            notFoundLabel="No tax types"
                          />
                        </div>
                        <div className="lg:col-span-3">
                          <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Tax Base ($)</label>
                          <input type="number" value={draftLine.debitAmount || ''} min={0} step="0.01"
                            onChange={e => updateDraftLine({ debitAmount: Number(e.target.value) || 0, creditAmount: 0 })}
                            placeholder="0.00"
                            className="w-full rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 px-2.5 py-1.5 text-xs text-gray-900 dark:text-white text-right font-mono" />
                        </div>
                        <div className="lg:col-span-4 flex items-end pb-1">
                          {selectedTax && draftLine.debitAmount > 0 ? (
                            <p className="text-[11px] text-gray-500 dark:text-gray-400">
                              Tax amount: <strong className="text-gray-900 dark:text-white">
                                {formatCurrency(Math.round(draftLine.debitAmount * selectedTax.rate))}
                              </strong>
                              <span className="block text-gray-400 dark:text-gray-500">
                                {selectedTax.rate}% · {selectedTax.type === 'input' ? 'debit (input VAT)' : 'credit (output VAT)'}
                              </span>
                            </p>
                          ) : (
                            <p className="text-[11px] text-gray-400 dark:text-gray-500">Pick a tax type and enter the base amount.</p>
                          )}
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                        <div>
                          <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Supplier Name</label>
                          <input type="text" value={draftLine.supplierName}
                            onChange={e => updateDraftLine({ supplierName: e.target.value })}
                            placeholder="Supplier"
                            className="w-full rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 px-2.5 py-1.5 text-xs text-gray-900 dark:text-white placeholder:text-gray-400" />
                        </div>
                        <div>
                          <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Supplier Tax ID</label>
                          <input type="text" value={draftLine.supplierTaxId}
                            onChange={e => updateDraftLine({ supplierTaxId: e.target.value })}
                            placeholder="Tax ID"
                            className="w-full rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 px-2.5 py-1.5 text-xs text-gray-900 dark:text-white placeholder:text-gray-400" />
                        </div>
                        <div>
                          <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Invoice #</label>
                          <input type="text" value={draftLine.invoiceNumber}
                            onChange={e => updateDraftLine({ invoiceNumber: e.target.value })}
                            placeholder="Invoice number"
                            className="w-full rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 px-2.5 py-1.5 text-xs text-gray-900 dark:text-white placeholder:text-gray-400" />
                        </div>
                        <div>
                          <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Invoice Date</label>
                          <input type="date" value={draftLine.invoiceDate}
                            onChange={e => updateDraftLine({ invoiceDate: e.target.value })}
                            className="w-full rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 px-2.5 py-1.5 text-xs text-gray-900 dark:text-white" />
                        </div>
                      </div>
                      <div className="flex items-center justify-between gap-2 pt-1">
                        <p className="text-[11px] text-gray-400 dark:text-gray-500">
                          Generates the computed tax line on <strong>{selectedTax?.accountCode || 'the tax account'}</strong>. Amount stays editable.
                        </p>
                        <button type="button"
                          onClick={generateTaxLineDraft}
                          disabled={!draftLine.vatCodeId || !(draftLine.debitAmount > 0)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 text-white text-xs font-medium hover:bg-amber-600 disabled:opacity-50 transition-colors">
                          <Percent className="w-3.5 h-3.5" /> Generate Tax Line
                        </button>
                      </div>
                    </div>
                  )
                }

                if (isGenerator && draftLine.lineType === 'payment') {
                  return (
                    /* ── Payment generator card ── */
                    <div className="space-y-3 rounded-xl border border-dashed border-blue-300 dark:border-blue-700 bg-blue-50/40 dark:bg-blue-950/10 p-3">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2">
                        <div className="lg:col-span-4">
                          <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Partner *</label>
                          <SearchSelect
                            options={cardPartners}
                            value={draftLine.businessPartnerId}
                            onChange={(val) => {
                              const pid = val ? Number(val) : null
                              const partner = pid ? partnerMap.get(pid) : undefined
                              updateDraftLine({
                                businessPartnerId: pid,
                                allocations: pid ? draftLine.allocations : [],
                                ...(pid && !draftLine.accountCode && partner ? { accountCode: resolveControlAccount(partner) } : {}),
                              })
                              if (pid) fetchOpenInvoices(pid)
                            }}
                            placeholder="Select partner..."
                            searchPlaceholder="Search partners..."
                            notFoundLabel="No partners"
                          />
                        </div>
                        <div className="lg:col-span-3">
                          <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">AR/AP Account *</label>
                          <SearchSelect
                            options={accountOptions}
                            value={draftLine.accountCode || ''}
                            onChange={(val) => updateDraftLine({ accountCode: val ? String(val) : '' })}
                            placeholder="Control account..."
                            searchPlaceholder="Search accounts..."
                            notFoundLabel="No accounts"
                          />
                        </div>
                        <div className="lg:col-span-3">
                          <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Cash / Bank *</label>
                          <SearchSelect
                            options={accountOptions}
                            value={draftLine.cashAccountCode || ''}
                            onChange={(val) => updateDraftLine({ cashAccountCode: val ? String(val) : '' })}
                            placeholder="Cash account..."
                            searchPlaceholder="Search accounts..."
                            notFoundLabel="No accounts"
                          />
                        </div>
                        <div className="lg:col-span-2">
                          <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">WHT Tax</label>
                          <SearchSelect
                            options={taxTypeOptions}
                            value={draftLine.vatCodeId}
                            onChange={(val) => updateDraftLine({ vatCodeId: val ? Number(val) : null })}
                            placeholder="Optional..."
                            searchPlaceholder="Search tax types..."
                            notFoundLabel="No tax types"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Supplier Invoice # (WHT ref)</label>
                          <input type="text" value={draftLine.invoiceNumber}
                            onChange={e => updateDraftLine({ invoiceNumber: e.target.value })}
                            placeholder="Invoice number"
                            className="w-full rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 px-2.5 py-1.5 text-xs text-gray-900 dark:text-white placeholder:text-gray-400" />
                        </div>
                        <div>
                          <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Invoice Date</label>
                          <input type="date" value={draftLine.invoiceDate}
                            onChange={e => updateDraftLine({ invoiceDate: e.target.value })}
                            className="w-full rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 px-2.5 py-1.5 text-xs text-gray-900 dark:text-white" />
                        </div>
                      </div>

                      {draftLine.businessPartnerId && (loadingInvoices === draftLine.businessPartnerId ? (
                        <div className="flex items-center gap-2 text-[11px] text-gray-400">
                          <Loader2 className="w-3.5 h-3.5 animate-spin" /> Loading open invoices...
                        </div>
                      ) : (
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <p className="text-[11px] font-medium text-gray-500 dark:text-gray-400">Open invoices for {partnerMap.get(draftLine.businessPartnerId)?.name}</p>
                            <button type="button" onClick={() => fetchOpenInvoices(draftLine.businessPartnerId!, true)}
                              className="text-[11px] font-medium text-brand-500 hover:text-brand-600">Refresh</button>
                          </div>
                          {invoices.length === 0 ? (
                            <p className="text-[11px] text-gray-400 py-2">No open invoices for this partner.</p>
                          ) : (
                            <div className="rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                              <table className="w-full text-xs">
                                <thead>
                                  <tr className="bg-gray-100 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                                    <th className="text-left py-1.5 px-2 font-medium text-gray-500 dark:text-gray-400">Pay</th>
                                    <th className="text-left py-1.5 px-2 font-medium text-gray-500 dark:text-gray-400">Invoice</th>
                                    <th className="text-left py-1.5 px-2 font-medium text-gray-500 dark:text-gray-400">Date</th>
                                    <th className="text-right py-1.5 px-2 font-medium text-gray-500 dark:text-gray-400">Balance</th>
                                    <th className="text-left py-1.5 px-2 font-medium text-gray-500 dark:text-gray-400">Amount ($)</th>
                                    <th className="text-left py-1.5 px-2 font-medium text-gray-500 dark:text-gray-400">Notes</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                                  {invoices.map(inv => {
                                    const alloc = draftLine.allocations.find(a => a.invoiceId === inv.id)
                                    const balance = (inv.totalAmount - inv.paidAmount) / 100
                                    return (
                                      <tr key={inv.id} className="bg-white dark:bg-gray-800">
                                        <td className="py-1.5 px-2">
                                          <input type="checkbox"
                                            checked={!!alloc}
                                            onChange={e => e.target.checked ? updateDraftAllocation(inv.id, { amount: balance }) : removeDraftAllocation(inv.id)}
                                            className="rounded border-gray-300 dark:border-gray-600 text-brand-500 focus:ring-brand-500" />
                                        </td>
                                        <td className="py-1.5 px-2 font-mono text-gray-700 dark:text-gray-300">{inv.invoiceNumber}</td>
                                        <td className="py-1.5 px-2 text-gray-500 dark:text-gray-400">{inv.invoiceDate}</td>
                                        <td className="py-1.5 px-2 text-right font-medium text-gray-700 dark:text-gray-300">{formatCurrency(inv.totalAmount - inv.paidAmount)}</td>
                                        <td className="py-1.5 px-2">
                                          <input type="number" min={0} step="0.01" value={alloc?.amount ?? ''}
                                            onChange={e => updateDraftAllocation(inv.id, { amount: Number(e.target.value) || 0 })}
                                            placeholder="0.00"
                                            className="w-24 rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 px-1.5 py-1 text-xs text-right font-mono text-gray-900 dark:text-white" />
                                        </td>
                                        <td className="py-1.5 px-2">
                                          <input type="text" value={alloc?.notes ?? ''}
                                            onChange={e => updateDraftAllocation(inv.id, { notes: e.target.value })}
                                            placeholder="Note"
                                            className="w-full rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 px-1.5 py-1 text-xs text-gray-900 dark:text-white" />
                                        </td>
                                      </tr>
                                    )
                                  })}
                                </tbody>
                              </table>
                            </div>
                          )}
                          <div className="flex items-center justify-between gap-2 mt-2">
                            <p className="text-[11px] text-gray-500 dark:text-gray-400">
                              Allocated: <strong className="text-gray-900 dark:text-white">{formatCurrency(Math.round(allocTotal * 100))}</strong>
                              {overAllocated && (
                                <span className="ml-1.5 text-red-500">Exceeds open balance ({formatCurrency(Math.round(invoiceBalanceSum * 100))})</span>
                              )}
                            </p>
                            <button type="button"
                              onClick={generatePaymentLinesDraft}
                              disabled={!draftLine.businessPartnerId || !draftLine.accountCode || !draftLine.cashAccountCode || allocTotal <= 0 || overAllocated}
                              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-500 text-white text-xs font-medium hover:bg-blue-600 disabled:opacity-50 transition-colors">
                              <Receipt className="w-3.5 h-3.5" /> Generate Payment Lines
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )
                }

                /* ── Editable line (normal / generated tax / payment) ── */
                return (
                  <div className="rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50 p-3 space-y-2">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2">
                      <div className="lg:col-span-3">
                        <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Account *</label>
                        <SearchSelect
                          options={accountOptions}
                          value={draftLine.accountCode || ''}
                          onChange={(val) => updateDraftLine({ accountCode: val ? String(val) : '' })}
                          placeholder="Select account..."
                          searchPlaceholder="Search accounts..."
                          notFoundLabel="No accounts found"
                        />
                      </div>
                      <div className="lg:col-span-3">
                        <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Description</label>
                        <input type="text" value={draftLine.description}
                          onChange={e => updateDraftLine({ description: e.target.value })}
                          placeholder="Line description"
                          className="w-full rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 px-2.5 py-1.5 text-xs text-gray-900 dark:text-white placeholder:text-gray-400" />
                      </div>
                      <div className="lg:col-span-2">
                        <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Debit ($)</label>
                        <input type="number" value={draftLine.debitAmount || ''} min={0} step="0.01"
                          onChange={e => {
                            const val = Number(e.target.value) || 0
                            updateDraftLine({ debitAmount: val, ...(val > 0 ? { creditAmount: 0 } : {}) })
                          }}
                          className="w-full rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 px-2.5 py-1.5 text-xs text-gray-900 dark:text-white text-right font-mono" />
                      </div>
                      <div className="lg:col-span-2">
                        <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Credit ($)</label>
                        <input type="number" value={draftLine.creditAmount || ''} min={0} step="0.01"
                          onChange={e => {
                            const val = Number(e.target.value) || 0
                            updateDraftLine({ creditAmount: val, ...(val > 0 ? { debitAmount: 0 } : {}) })
                          }}
                          className="w-full rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 px-2.5 py-1.5 text-xs text-gray-900 dark:text-white text-right font-mono" />
                      </div>
                      <div className="lg:col-span-2">
                        <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">Cost Center</label>
                        <SearchSelect
                          options={lineCcOptions.map(c => ({ id: c.id, label: `${c.code} — ${c.name}` }))}
                          value={draftLine.costCenterId}
                          onChange={(val) => updateDraftLine({ costCenterId: val ? Number(val) : null })}
                          placeholder={lineCcOptions.length === 0 ? 'Not linked' : 'Select...'}
                          noneLabel="None"
                          searchPlaceholder="Search cost centers..."
                          notFoundLabel="No cost centers"
                          disabled={lineCcOptions.length === 0}
                        />
                      </div>
                    </div>

                    {acct && (
                      <p className="text-[11px] text-gray-400">
                        {acct.name} ({draftLine.accountCode})
                      </p>
                    )}

                    {draftLine.lineType === 'tax' && (draftLine.supplierName || draftLine.supplierTaxId || draftLine.invoiceNumber || draftLine.invoiceDate) && (
                      <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-gray-500 dark:text-gray-400">
                        {draftLine.supplierName && <span>Supplier: <strong>{draftLine.supplierName}</strong></span>}
                        {draftLine.supplierTaxId && <span>Tax ID: {draftLine.supplierTaxId}</span>}
                        {draftLine.invoiceNumber && <span>Invoice: {draftLine.invoiceNumber}</span>}
                        {draftLine.invoiceDate && <span>Date: {draftLine.invoiceDate}</span>}
                      </div>
                    )}

                    {draftLine.lineType === 'payment' && draftLine.allocations.length > 0 && (
                      <div className="space-y-0.5">
                        <p className="text-[11px] font-medium text-gray-500 dark:text-gray-400">Allocations</p>
                        {draftLine.allocations.map(a => {
                          const inv = (draftLine.businessPartnerId ? openInvoices[draftLine.businessPartnerId] : undefined)?.find(i => i.id === a.invoiceId)
                          return (
                            <p key={a.id} className="text-[11px] text-gray-500 dark:text-gray-400 flex items-center gap-2">
                              <span className="font-mono">{inv?.invoiceNumber || `#${a.invoiceId}`}</span>
                              <span className="font-medium text-gray-900 dark:text-white">{formatCurrency(Math.round(a.amount * 100))}</span>
                              {a.notes && <span className="text-gray-400">— {a.notes}</span>}
                            </p>
                          )
                        })}
                      </div>
                    )}
                  </div>
                )
              })()}
            </>
          )}
        </div>

        {/* Line modal footer */}
        <div className="p-6 border-t border-gray-200 dark:border-gray-700 flex items-center justify-end gap-3 bg-gray-50 dark:bg-gray-900/50 rounded-b-3xl">
          <Button variant="outline" size="sm" onClick={closeLineModal}>Cancel</Button>
          <Button size="sm" onClick={saveLineFromModal} disabled={!draftLine || (draftLine.lineType !== 'normal' && !draftLine.accountCode)}
            className="flex items-center gap-2">
            <Plus className="w-3.5 h-3.5" />
            {editingLineId ? 'Save Line' : 'Add Line'}
          </Button>
        </div>
      </Modal>

      {/* ═══════════════════════════════════════════════════════════════════
          VIEW ENTRY DETAIL MODAL
         ═══════════════════════════════════════════════════════════════════ */}
      <Modal isOpen={!!viewEntry} onClose={() => setViewEntry(null)} className="max-w-3xl p-0" showCloseButton={false}>
        <ModalHeader title={`Entry ${viewEntry?.entryNumber}`} onClose={() => setViewEntry(null)}>
          {viewEntry && (
            <StatusBadge label={viewEntry.status.charAt(0).toUpperCase() + viewEntry.status.slice(1)} color={statusStyles[viewEntry.status]} size="sm" className="mt-1" />
          )}
        </ModalHeader>

        <div className="p-6 max-h-[70vh] overflow-y-auto">
          {viewLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-5 h-5 text-brand-500 animate-spin" />
              <span className="ml-2 text-sm text-gray-400">Loading...</span>
            </div>
          ) : viewEntry ? (
            <div className="space-y-6">
              {/* Header info */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 rounded-xl bg-gray-50 dark:bg-gray-800/50">
                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Date</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white mt-0.5">{viewEntry.entryDate}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Reference</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white mt-0.5">{viewEntry.referenceNumber || '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Posted By</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white mt-0.5">{viewEntry.postedBy || '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Category</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white mt-0.5">
                    {viewEntry.categoryId && categoryMap.has(viewEntry.categoryId)
                      ? categoryMap.get(viewEntry.categoryId)!.name
                      : '—'}
                  </p>
                </div>
              </div>

              {/* Description */}
              <div>
                <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">Description</p>
                <p className="text-sm text-gray-900 dark:text-white">{viewEntry.description}</p>
              </div>

              {/* Lines */}
              <div>
                <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">Line Items</h4>
                <div className="rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-50 dark:bg-gray-800/50 border-b border-gray-200 dark:border-gray-700">
                        <th className="text-left py-2.5 px-3 text-xs font-medium text-gray-500 dark:text-gray-400">#</th>
                        <th className="text-left py-2.5 px-3 text-xs font-medium text-gray-500 dark:text-gray-400">Type</th>
                        <th className="text-left py-2.5 px-3 text-xs font-medium text-gray-500 dark:text-gray-400">Account</th>
                        <th className="text-left py-2.5 px-3 text-xs font-medium text-gray-500 dark:text-gray-400">Description</th>
                        <th className="text-right py-2.5 px-3 text-xs font-medium text-gray-500 dark:text-gray-400">Debit</th>
                        <th className="text-right py-2.5 px-3 text-xs font-medium text-gray-500 dark:text-gray-400">Credit</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                      {viewLines.length === 0 ? (
                        <tr><td colSpan={6} className="py-8 text-center text-sm text-gray-400">No line items</td></tr>
                      ) : (
                        viewLines.map(line => {
                          const acct = accountMap.get(line.accountCode)
                          const lineType = lineTypeConfig[line.lineType || 'normal']
                          return (
                            <tr key={line.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30">
                              <td className="py-2 px-3 text-xs text-gray-400">{line.lineNumber}</td>
                              <td className="py-2 px-3">
                                <span className={`inline-flex items-center text-[10px] font-medium px-1.5 py-0.5 rounded-full ${lineType.bg} ${lineType.text}`}>
                                  {lineType.label}
                                </span>
                              </td>
                              <td className="py-2 px-3 text-xs font-mono font-medium text-gray-900 dark:text-white">
                                {line.accountCode}
                                {acct && <span className="text-gray-400 ml-1">({acct.name})</span>}
                              </td>
                              <td className="py-2 px-3 text-xs text-gray-600 dark:text-gray-300">{line.description}</td>
                              <td className="py-2 px-3 text-xs text-right font-medium text-green-600 dark:text-green-400">
                                {line.debitAmount > 0 ? formatCurrency(line.debitAmount) : '—'}
                              </td>
                              <td className="py-2 px-3 text-xs text-right font-medium text-red-600 dark:text-red-400">
                                {line.creditAmount > 0 ? formatCurrency(line.creditAmount) : '—'}
                              </td>
                            </tr>
                          )
                        })
                      )}
                    </tbody>
                    <tfoot>
                      <tr className="bg-gray-50 dark:bg-gray-800/50 border-t border-gray-200 dark:border-gray-700">
                        <td colSpan={4} className="py-2.5 px-3 text-xs font-semibold text-gray-900 dark:text-white text-right">Totals</td>
                        <td className="py-2.5 px-3 text-xs font-semibold text-green-600 dark:text-green-400 text-right">
                          ${(viewLines.reduce((s, l) => s + l.debitAmount, 0) / 100).toFixed(2)}
                        </td>
                        <td className="py-2.5 px-3 text-xs font-semibold text-red-600 dark:text-red-400 text-right">
                          ${(viewLines.reduce((s, l) => s + l.creditAmount, 0) / 100).toFixed(2)}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            <p className="text-center text-sm text-gray-400 py-8">Entry not found.</p>
          )}
        </div>

        <div className="p-6 border-t border-gray-200 dark:border-gray-700 flex items-center justify-end bg-gray-50 dark:bg-gray-900/50 rounded-b-3xl">
          <Button variant="outline" size="sm" onClick={() => setViewEntry(null)}>Close</Button>
        </div>
      </Modal>

      {/* ═══════════════════════════════════════════════════════════════════
          POST CONFIRMATION
         ═══════════════════════════════════════════════════════════════════ */}
      <Modal isOpen={!!postTarget} onClose={() => setPostTarget(null)} className="max-w-md p-6">
        {postTarget && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-green-50 dark:bg-green-950/50 p-2.5">
                <CheckCircle className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Post Entry</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">{postTarget.entryNumber}</p>
              </div>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Are you sure you want to post <strong>{postTarget.entryNumber}</strong>?
              This will lock the entry and update account balances. This action cannot be undone.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <Button variant="outline" size="sm" onClick={() => setPostTarget(null)}>Cancel</Button>
              <Button size="sm" onClick={handlePost} disabled={posting}
                className="flex items-center gap-2 !bg-green-600 hover:!bg-green-700">
                {posting && <Loader2 className="w-4 h-4 animate-spin" />}
                {posting ? 'Posting...' : 'Post Entry'}
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* ═══════════════════════════════════════════════════════════════════
          CANCEL CONFIRMATION
         ═══════════════════════════════════════════════════════════════════ */}
      <Modal isOpen={!!cancelTarget} onClose={() => setCancelTarget(null)} className="max-w-md p-6">
        {cancelTarget && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-red-50 dark:bg-red-950/50 p-2.5">
                <AlertTriangle className="w-5 h-5 text-red-500" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Cancel Entry</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">{cancelTarget.entryNumber}</p>
              </div>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Are you sure you want to cancel <strong>{cancelTarget.entryNumber}</strong>?
              This will mark the entry as cancelled and it won't affect financial reports.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <Button variant="outline" size="sm" onClick={() => setCancelTarget(null)}>Cancel</Button>
              <Button size="sm" onClick={handleCancel} className="!bg-red-500 hover:!bg-red-600">Cancel Entry</Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}

