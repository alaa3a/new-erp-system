import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { setupTestDatabase, teardownTestDatabase, seedTestData } from '../test-helper';
import { accountRepository } from '../../repositories/accountRepository';
import { db } from '../../db';

describe('accountRepository', () => {
  beforeAll(async () => {
    await setupTestDatabase();
    seedTestData();
  });

  afterAll(() => {
    teardownTestDatabase();
  });

  describe('findAll', () => {
    it('should return all active accounts ordered by code', () => {
      const accounts = accountRepository.findAll();
      expect(accounts.length).toBeGreaterThan(0);
      // Check ordering
      for (let i = 1; i < accounts.length; i++) {
        expect(accounts[i].code.localeCompare(accounts[i - 1].code)).toBeGreaterThanOrEqual(0);
      }
      // All accounts should be active
      accounts.forEach(a => expect(a.isActive).toBe(true));
    });
  });

  describe('findHierarchy', () => {
    it('should return all accounts including inactive', () => {
      const accounts = accountRepository.findHierarchy();
      // Should include root accounts (1-5)
      const rootAccts = accounts.filter(a => a.parentId === null);
      expect(rootAccts.length).toBeGreaterThanOrEqual(5);
    });
  });

  describe('findById', () => {
    it('should return account by id', () => {
      const account = accountRepository.findById(1);
      expect(account).not.toBeNull();
      expect(account!.id).toBe(1);
    });

    it('should return null for non-existent id', () => {
      const account = accountRepository.findById(99999);
      expect(account).toBeNull();
    });
  });

  describe('findByCode', () => {
    it('should return account by code', () => {
      const account = accountRepository.findByCode('1');
      expect(account).not.toBeNull();
      expect(account!.code).toBe('1');
    });

    it('should return null for non-existent code', () => {
      const account = accountRepository.findByCode('ZZZZ');
      expect(account).toBeNull();
    });
  });

  describe('create', () => {
    it('should create a new account and return its id', () => {
      const id = accountRepository.create({
        code: '601',
        name: 'Test Expense',
        type: 'expense',
        parentId: 5,
        costCenterId: null,
        partnerRole: 'none',
        isActive: true,
        isSystemAccount: false,
        description: 'Test account',
      });
      expect(id).toBeGreaterThan(0);

      const created = accountRepository.findById(id);
      expect(created).not.toBeNull();
      expect(created!.code).toBe('601');
      expect(created!.name).toBe('Test Expense');
      expect(created!.type).toBe('expense');
      expect(created!.parentId).toBe(5);
      expect(created!.isActive).toBe(true);
      expect(created!.version).toBe(1);
    });

    it('should persist the partnerRole flag and default it to none', () => {
      const id = accountRepository.create({
        code: '604', name: 'AR Flag Account', type: 'asset',
        parentId: null, costCenterId: null, partnerRole: 'ar', isActive: true,
        isSystemAccount: false, description: '',
      });
      expect(accountRepository.findById(id)!.partnerRole).toBe('ar');

      const id2 = accountRepository.create({
        code: '605', name: 'Default Role', type: 'asset',
        parentId: null, costCenterId: null, partnerRole: 'none', isActive: true,
        isSystemAccount: false, description: '',
      });
      expect(accountRepository.findById(id2)!.partnerRole).toBe('none');
    });

    it('should update the partnerRole flag', () => {
      const id = accountRepository.create({
        code: '606', name: 'Role Update', type: 'asset',
        parentId: null, costCenterId: null, partnerRole: 'none', isActive: true,
        isSystemAccount: false, description: '',
      });
      const before = accountRepository.findById(id)!;
      const ok = accountRepository.update(id, { partnerRole: 'both' }, before.version);
      expect(ok).toBe(true);
      expect(accountRepository.findById(id)!.partnerRole).toBe('both');
    });
  });

  describe('update', () => {
    it('should update account fields and increment version', () => {
      const account = accountRepository.findById(1)!;
      const versionBefore = account.version;

      const success = accountRepository.update(1, { name: 'Updated Assets' }, versionBefore);
      expect(success).toBe(true);

      const updated = accountRepository.findById(1)!;
      expect(updated.name).toBe('Updated Assets');
      expect(updated.version).toBe(versionBefore + 1);
    });

    it('should return false on version conflict', () => {
      const success = accountRepository.update(1, { name: 'Conflict' }, 999);
      expect(success).toBe(false);
    });
  });

  describe('hardDelete', () => {
    it('should permanently delete the account', () => {
      const id = accountRepository.create({
        code: '602', name: 'Delete Me', type: 'expense',
        parentId: null, costCenterId: null, partnerRole: 'none', isActive: true,
        isSystemAccount: false, description: '',
      });
      const before = accountRepository.findById(id)!;
      const success = accountRepository.hardDelete(id, before.version);
      expect(success).toBe(true);

      // Row should be fully removed (not just deactivated)
      expect(accountRepository.findById(id)).toBeNull();
      const all = accountRepository.findAll();
      expect(all.find(a => a.id === id)).toBeUndefined();
    });
  });

  describe('toggleActive', () => {
    it('should toggle account active state', () => {
      const id = accountRepository.create({
        code: '603', name: 'Toggle Me', type: 'expense',
        parentId: null, costCenterId: null, partnerRole: 'none', isActive: true,
        isSystemAccount: false, description: '',
      });
      const before = accountRepository.findById(id)!;
      expect(before.isActive).toBe(true);

      accountRepository.toggleActive(id, false, before.version);
      const toggled = accountRepository.findById(id)!;
      expect(toggled.isActive).toBe(false);
    });
  });

  describe('hasChildren', () => {
    it('should return true for parent accounts', () => {
      // Account 1 (Assets) should have children
      expect(accountRepository.hasChildren(1)).toBe(true);
    });

    it('should return false for leaf accounts', () => {
      expect(accountRepository.hasChildren(99999)).toBe(false);
    });
  });

  describe('usage checks', () => {
    it('should return false for unused accounts', () => {
      expect(accountRepository.isUsedInEntries('999')).toBe(false);
      expect(accountRepository.isUsedInInvoiceLines('999')).toBe(false);
      expect(accountRepository.isUsedInPostingProfiles('999')).toBe(false);
    });
  });

  describe('getUsageMap', () => {
    it('should return usage keyed by account code', () => {
      const usage = accountRepository.getUsageMap();
      expect(typeof usage).toBe('object');
      // Seed posting profile uses account '102' (AR) and seed tax type uses '202'
      const arUsage = usage['102'];
      expect(arUsage).toBeDefined();
      expect(arUsage.postingProfiles.length).toBeGreaterThan(0);
      const taxUsage = usage['202'];
      expect(taxUsage).toBeDefined();
      expect(taxUsage.taxCodes.length).toBeGreaterThan(0);
    });
  });

  describe('getActiveProfileRoles', () => {
    it('should report AR/AP usage only from active profiles', () => {
      // Seed profile maps '102' as AR and '201' as AP
      expect(accountRepository.getActiveProfileRoles('102')).toEqual({ asAr: true, asAp: false });
      expect(accountRepository.getActiveProfileRoles('201')).toEqual({ asAr: false, asAp: true });
      expect(accountRepository.getActiveProfileRoles('999')).toEqual({ asAr: false, asAp: false });
    });

    it('should ignore soft-deleted (inactive) profiles', () => {
      const id = accountRepository.create({
        code: '607', name: 'Role Profile', type: 'asset',
        parentId: null, costCenterId: null, partnerRole: 'none', isActive: true,
        isSystemAccount: false, description: '',
      });
      const profile = (db.prepare('SELECT id, version FROM posting_profile LIMIT 1').get() as any);
      db.prepare('UPDATE posting_profile SET isActive=0 WHERE id=?').run(profile.id);
      // '102' was AR in the (now inactive) seed profile → should no longer report AR
      expect(accountRepository.getActiveProfileRoles('102').asAr).toBe(false);
      db.prepare('UPDATE posting_profile SET isActive=1 WHERE id=?').run(profile.id);
      expect(id).toBeGreaterThan(0);
    });
  });
});
