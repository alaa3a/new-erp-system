import { z } from 'zod'
import { entityCodeSchema, entityNameSchema, optionalString } from './common'

export const accountTypeEnum = z.enum(['asset', 'liability', 'equity', 'revenue', 'expense'])
export const accountPartnerRoleEnum = z.enum(['none', 'ar', 'ap', 'both'])

export const createAccountSchema = z.object({
  code: entityCodeSchema,
  name: entityNameSchema,
  type: accountTypeEnum,
  parentId: z.number().int().positive().nullable().optional().default(null),
  partnerRole: accountPartnerRoleEnum.optional().default('none'),
  description: optionalString,
})

export const updateAccountSchema = createAccountSchema.partial().extend({
  action: z.enum(['toggleActive', 'linkCostCenter']).optional(),
  isActive: z.boolean().optional(),
  cascade: z.boolean().optional(),
  costCenterId: z.number().int().positive().nullable().optional(),
})
