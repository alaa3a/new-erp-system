import { z } from 'zod'
import { entityNameSchema, optionalString } from './common'

const base = z.object({
  code: z.string('Code is required').min(1).max(20),
  name: entityNameSchema,
  isGroup: z.boolean().optional().default(false),
  filingPeriod: z.enum(['monthly', 'quarterly', 'annually']).optional().default('monthly'),
  rate: z.number().min(0).max(100, 'Rate must be 0-100').optional().default(0),
  type: z.enum(['output', 'input']).optional().default('output'),
  parentId: z.number().int().positive().nullable().optional().default(null),
  accountCode: z.string().max(50).optional().default(''),
  description: optionalString,
  effectiveFrom: z.string().max(20).optional().default(''),
  effectiveTo: z.string().max(20).nullable().optional().default(null),
  isActive: z.boolean().optional().default(true),
})

export const createTaxCodeSchema = base.superRefine((data, ctx) => {
  if (data.isGroup) {
    // Sub-groups are not supported — groups must be top-level
    if (data.parentId != null) {
      ctx.addIssue({ code: 'custom', path: ['parentId'], message: 'Sub-groups are not supported. Tax groups must be top-level; add tax types under a group.' })
    }
    return
  }
  // Tax type rules
  if (data.rate === undefined) {
    ctx.addIssue({ code: 'custom', path: ['rate'], message: 'Rate is required for tax types' })
  }
  if (data.type === undefined) {
    ctx.addIssue({ code: 'custom', path: ['type'], message: 'Type is required for tax types' })
  }
  if (data.accountCode === '' || data.accountCode === undefined) {
    ctx.addIssue({ code: 'custom', path: ['accountCode'], message: 'Posting account is required for tax types' })
  }
  if (data.parentId === null || data.parentId === undefined) {
    ctx.addIssue({ code: 'custom', path: ['parentId'], message: 'Tax types must belong to a tax group' })
  }
})

export const updateTaxCodeSchema = base.partial()
